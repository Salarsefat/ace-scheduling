#!/usr/bin/env python3
"""Fast sanity checks for the simulator. Run with:  python -m pytest tests -q
or, without pytest installed:  python tests/test_sanity.py

These are cheap invariants, not a substitute for the full reproduction; they
run in a few seconds and catch the failure modes that would silently corrupt a
result (broken precedence, overlapping intervals, non-deterministic seeding).
"""
from __future__ import annotations
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ace.experiments import Instance, run_one, METHODS      # noqa: E402
from ace.scheduler import Protocol                          # noqa: E402
from ace.workload import layered_dag, classify              # noqa: E402
from ace.perturbation import Perturbation                   # noqa: E402


def test_determinism():
    """The same seed must give bit-identical makespans."""
    a = run_one("ACE", Instance(3, m=200))["makespan"]
    b = run_one("ACE", Instance(3, m=200))["makespan"]
    assert a == b, f"non-deterministic: {a} != {b}"


def test_pairing():
    """Every allocator must see the same instance and the same perturbation."""
    i1, i2 = Instance(4, m=200), Instance(4, m=200)
    assert np.allclose(i1.W, i2.W)
    assert np.allclose(i1.pert.rho, i2.pert.rho)


def test_precedence_and_nonoverlap():
    """Eq. (7): no two tasks overlap on one machine; Eq. (6): precedence with
    communication is respected.  Start/finish times are captured through a
    metrics spy so that no scheduler code needs to change."""
    import ace.scheduler as sch
    from ace.allocators import ACE
    inst = Instance(5, m=200)
    captured = {}
    orig = sch._metrics

    def spy(wf, plat, W, tl, assign, S, F, rdy):
        captured.update(S=S.copy(), F=F.copy(), assign=assign.copy())
        return orig(wf, plat, W, tl, assign, S, F, rdy)

    sch._metrics = spy
    try:
        res = sch.run_schedule(inst.wf, inst.plat, inst.W, ACE(n=inst.plat.n),
                               inst.pert, Protocol(), W_true=inst.W_true)
    finally:
        sch._metrics = orig
    assert res["makespan"] > 0
    S, F, assign = captured["S"], captured["F"], captured["assign"]
    for j in range(inst.plat.n):                       # Eq. (7): non-overlap
        iv = sorted((S[i], F[i]) for i in range(inst.m) if assign[i] == j)
        for (a1, b1), (a2, b2) in zip(iv, iv[1:]):
            assert a2 >= b1 - 1e-9, f"overlap on machine {j}"
    for (p, k) in inst.wf.edges:                       # Eq. (6): precedence
        c = (0.0 if assign[p] == assign[k]
             else inst.wf.data.get((p, k), 0.0) / inst.plat.bw[assign[k]])
        assert S[k] >= F[p] + c - 1e-9, f"edge ({p},{k}) violated"


def test_perturbation_is_lower_bounded():
    """(A2): the base perturbation never drops below 1."""
    p = Perturbation(np.random.default_rng(0), 34, 300, 2.0)
    assert p.rho.min() >= 1.0 - 1e-12


def test_two_sided_mode_admits_speedups():
    """The out-of-class mode must actually produce rho < 1."""
    p = Perturbation(np.random.default_rng(0), 34, 300, 2.0, mode="twosided")
    assert (p.rho < 1.0).any()


def test_task_types_recoverable():
    """Eq. (1) must recover the type the generator intended for most tasks."""
    wf = layered_dag(np.random.default_rng(0), 300)
    assert set(np.unique(classify(wf.demands))) <= {0, 1, 2}
    assert len(np.unique(classify(wf.demands))) == 3


def test_all_allocators_run():
    """Every allocator completes a small workflow and schedules every task."""
    inst = Instance(6, m=120)
    for name in METHODS:
        r = run_one(name, inst)
        assert r["makespan"] > 0, name
        assert len(r["assign"]) == inst.m, name


def test_protocol_flags_change_nothing_for_heft():
    """HEFT does not learn, so relaxing P1/P2 must not change its makespan."""
    inst = Instance(7, m=200)
    base = run_one("HEFT", inst)["makespan"]
    for proto in (Protocol(p1=False), Protocol(p2=False)):
        assert run_one("HEFT", inst, protocol=proto)["makespan"] == base


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  PASS  {name}")
            except AssertionError as exc:
                fails += 1
                print(f"  FAIL  {name}: {exc}")
    print(f"\n{fails} failure(s)")
    sys.exit(1 if fails else 0)
