#!/usr/bin/env python3
"""Generate every external figure of the paper from results/raw/*.json.

Figure 1 (the method overview) is drawn in TikZ inside the manuscript and is
not produced here.  All other figures are written to figures/ as vector PDF.

Usage:  python scripts/make_figures.py [--only fig_noise ...]
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "results" / "raw"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

plt.rcParams.update({
    "font.family": "serif", "font.size": 8.5, "axes.labelsize": 8.5,
    "axes.titlesize": 9, "legend.fontsize": 7.5, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "axes.grid": True, "grid.alpha": 0.25,
    "grid.linewidth": 0.5, "axes.axisbelow": True, "figure.dpi": 150,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    "axes.spines.top": False, "axes.spines.right": False,
})

METHODS = ["CPOP", "PEFT", "HEFT", "LinUCB-C", "RAH", "LinUCB-W", "ACE"]
# Shared palette.  These are exactly the colours defined in the manuscript
# preamble for Fig. 1, so the whole paper uses one scheme.  All seven are
# distinguishable in greyscale by lightness as well as by hue.
COL = {"CPOP": "#6E7B8B",      # slate    -- classical, non-DAG-aware
       "PEFT": "#8C5A79",      # plum     -- classical, look-ahead
       "HEFT": "#2F6B47",      # forest   -- classical baseline
       "LinUCB-C": "#B0632A",  # rust     -- policy learning, cold
       "RAH": "#2C4F76",       # navy     -- the shared prior
       "LinUCB-W": "#9A6B10",  # ochre    -- policy learning, warm
       "ACE": "#1E5E3A"}       # deep green -- cost-model learning
MARK = {"CPOP": "D", "PEFT": "o", "HEFT": "^", "LinUCB-C": "o",
        "RAH": "s", "LinUCB-W": "s", "ACE": "*"}


def load(name):
    p = RAW / f"{name}.json"
    if not p.exists():
        raise FileNotFoundError(f"{p} missing -- run scripts/run_all.py first")
    return json.load(open(p))


def col(rows, m, key, **f):
    sel = [r for r in rows if r.get("method") == m
           and all(r.get(k) == v for k, v in f.items())]
    sel.sort(key=lambda r: r["seed"])
    return np.array([r[key] for r in sel], float)


def save(fig, name):
    try:
        fig.tight_layout(pad=0.35)
    except Exception:                                   # noqa: BLE001
        pass
    out = FIG / f"{name}.pdf"
    fig.savefig(out)
    plt.close(fig)
    print(f"  -> figures/{name}.pdf")


# --------------------------------------------------------------------------- #
def fig_main_comparison():
    rows = load("main")
    mk = {m: col(rows, m, "makespan") for m in METHODS}
    ms = {m: col(rows, m, "wallclock_ms").mean() for m in METHODS}
    fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.7),
                           gridspec_kw=dict(width_ratios=[1.55, 1]))
    y = np.arange(len(METHODS))[::-1]
    means = [mk[m].mean() for m in METHODS]
    sds = [mk[m].std(ddof=1) for m in METHODS]
    ax[0].barh(y, means, xerr=sds, height=0.62, capsize=2.5,
               color=[COL[m] for m in METHODS], edgecolor="white", linewidth=0.6,
               error_kw=dict(lw=0.8, ecolor="0.25"))
    h = mk["HEFT"].mean()
    ax[0].axvline(h, ls="--", lw=0.9, color="0.25")
    ax[0].text(h, y[0] + 0.55, "HEFT", rotation=90, va="bottom", ha="right",
               fontsize=7, color="0.25")
    g = 100 * (h - mk["ACE"].mean()) / h
    ax[0].annotate(f"$-${g:.2f}%", xy=(mk['ACE'].mean(), y[-1]),
                   xytext=(h + 60, y[-1]), fontsize=7.5, color=COL["ACE"],
                   va="center", arrowprops=dict(arrowstyle="->", lw=0.8,
                                                color=COL["ACE"]))
    ax[0].set_yticks(y, METHODS)
    ax[0].set_xlabel("Makespan (model time units)")
    ax[0].set_title("(a) Makespan, mean $\\pm$ s.d., 30 paired seeds", loc="left")
    ax[0].set_xlim(0.92 * min(means), 1.10 * max(np.array(means) + np.array(sds)))

    ax[1].barh(y, [ms[m] for m in METHODS], height=0.62,
               color=[COL[m] for m in METHODS], edgecolor="white", linewidth=0.6)
    for yy, m in zip(y, METHODS):
        ax[1].text(ms[m] * 1.06, yy, f"{ms[m]:.0f}", va="center", fontsize=7)
    ax[1].set_xscale("log")
    ax[1].set_yticks(y, [])
    ax[1].set_xlabel("Planning time per run (ms)")
    ax[1].set_title("(b) Planning time (log scale)", loc="left")
    ax[1].set_xlim(min(ms.values()) * 0.6, max(ms.values()) * 2.4)
    ax[1].xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.0f}"))
    save(fig, "fig_main_comparison")


def fig_scaling():
    rows = load("scaling")
    sizes = sorted({int(r["m"]) for r in rows})
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.4))
    for m in METHODS:
        mk = [np.mean([r["makespan"] for r in rows
                       if r["method"] == m and int(r["m"]) == s]) for s in sizes]
        sg = [np.mean([r["sigma_load"] for r in rows
                       if r["method"] == m and int(r["m"]) == s]) for s in sizes]
        tm = [np.mean([r["wallclock_ms"] for r in rows
                       if r["method"] == m and int(r["m"]) == s]) for s in sizes]
        kw = dict(color=COL[m], marker=MARK[m], ms=3.6, lw=1.1, label=m)
        ax[0].plot(sizes, mk, **kw)
        ax[1].plot(sizes, sg, **kw)
        ax[2].plot(sizes, tm, **kw)
    for a, t, yl in zip(ax, ["(a) Makespan", "(b) Load dispersion",
                             "(c) Planning time"],
                        ["Makespan (model time units)",
                         "$\\sigma_{\\mathrm{load}}$ (pp of utilisation)",
                         "Planning time (ms)"]):
        a.set_xlabel("Number of tasks $m$")
        a.set_ylabel(yl)
        a.set_title(t, loc="left", fontsize=8)
    ax[2].set_yscale("log")
    ax[0].legend(ncol=2, fontsize=6.4, frameon=False, loc="upper left")
    save(fig, "fig_scaling")


def fig_mechanism():
    d = load("mechanism")
    rho = np.array(d["rho"])
    hat = np.array(d["rho_hat"])
    sp = np.array(d["spearman"])
    err = np.array(d["abs_err"])
    k = np.arange(1, len(sp) + 1)
    final = np.array(d["rho_final"])
    pick = list(np.argsort(-final)[:2]) + [int(np.argsort(final)[0])]
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.35))
    cols = ["#1b1b1b", "#2C4F76", COL["ACE"]]
    for c, j in zip(cols, pick):
        ax[0].plot(k, hat[:, j], color=c, lw=1.1, label=f"VM {j}")
        ax[0].plot(k, rho[:, j], color=c, lw=0.9, ls="--", alpha=0.75)
    ax[0].set_ylabel("Slowdown factor")
    ax[0].set_title("(a) $\\hat{\\rho}_j$ solid, $\\rho_j(t)$ dashed", loc="left", fontsize=8)
    ax[0].legend(frameon=False, fontsize=6.8)

    ax[1].plot(k, err, color="#1b1b1b", lw=1.0)
    ax[1].set_ylabel("Mean $|\\hat{\\rho}_j-\\rho_j|$")
    ax[1].set_title("(b) Absolute estimation error", loc="left", fontsize=8)

    ax[2].plot(k, sp, color="#2C4F76", lw=1.0)
    dec = slice(int(0.9 * len(sp)), len(sp))
    ax[2].axhline(sp.mean(), color=COL["ACE"], ls=":", lw=1.0)
    ax[2].text(len(sp) * 0.03, sp.mean() - 0.11,
               f"whole run {sp.mean():.2f}", color=COL["ACE"], fontsize=6.8)
    ax[2].axhline(sp[dec].mean(), color="#B03000", ls=":", lw=1.0)
    ax[2].text(len(sp) * 0.03, sp[dec].mean() + 0.04,
               f"last decile {sp[dec].mean():.2f}", color="#B03000", fontsize=6.8)
    ax[2].set_ylim(-0.15, 1.05)
    ax[2].set_ylabel("Spearman rank agreement")
    ax[2].set_title("(c) Rank agreement, 34 VMs", loc="left", fontsize=8)
    for a in ax:
        a.set_xlabel("Completions observed")
    save(fig, "fig_mechanism")


def fig_warmup():
    A = np.array([r["advantage"] for r in load("warmup")])
    rows = load("main")
    fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.5),
                           gridspec_kw=dict(width_ratios=[1.15, 1]))
    k = np.arange(1, A.shape[1] + 1)
    med = np.median(A, axis=0)
    lo, hi = np.percentile(A, [25, 75], axis=0)
    ax[0].fill_between(k, lo, hi, color=COL["ACE"], alpha=0.18, lw=0,
                       label="interquartile range")
    ax[0].plot(k, med, color="#1b1b1b", lw=1.1)
    ax[0].axhline(0, color="#2C4F76", ls="--", lw=0.9)
    # median over seeds of the first completion at which each seed's advantage
    # turns positive -- the same statistic Section 5.2 reports
    firsts = []
    for a in A:
        pos_i = np.flatnonzero(a > 0)
        firsts.append(int(pos_i[0]) + 1 if len(pos_i) else A.shape[1])
    if firsts:
        be = int(np.median(firsts))
        ax[0].axvline(be, color="#B03000", ls=":", lw=1.0)
        ax[0].annotate(f"median break-even\nat completion {be}", xy=(be, 0),
                       xytext=(be + 90, med.max() * 0.55), fontsize=7,
                       color="#B03000",
                       arrowprops=dict(arrowstyle="->", lw=0.8, color="#B03000"))
    ax[0].set_xlabel("Completions observed")
    ax[0].set_ylabel("Cumulative advantage over RAH")
    ax[0].set_title("(a) Warm-up cost of calibration", loc="left")

    data = [col(rows, m, "makespan") for m in METHODS]
    bp = ax[1].boxplot(data, patch_artist=True, widths=0.6,
                       medianprops=dict(color="black", lw=1.0),
                       flierprops=dict(marker="o", ms=2.2, mfc="0.3", mec="none"))
    for patch, m in zip(bp["boxes"], METHODS):
        patch.set_facecolor(COL[m])
        patch.set_alpha(0.75)
        patch.set_linewidth(0.6)
    ax[1].set_xticks(range(1, len(METHODS) + 1), METHODS, rotation=40, ha="right")
    ax[1].set_ylabel("Makespan (model time units)")
    ax[1].set_title("(b) Per-seed distributions, $m=1000$", loc="left")
    save(fig, "fig_warmup")


def fig_protocol():
    s = json.load(open(ROOT / "results" / "processed" / "summary.json"))
    pc = s["protocol"]["per_condition"]
    order = ["full", "P3", "P1", "P2", "P4"]
    labels = ["Full\nprotocol\n(P1--P4)", "P3 off\nslowdown\noracle",
              "P1 off\nimmediate\nfeedback", "P2 off\ncounterfact.\nreward",
              "P4 off\nlocal\nadmission"]
    g = [pc[c]["gain"] for c in order]
    err = [[pc[c]["gain"] - pc[c]["ci"][0] for c in order],
           [pc[c]["ci"][1] - pc[c]["gain"] for c in order]]
    cols = ["#1b1b1b", "#B03000", "#6E7B8B", "#6E7B8B", COL["ACE"]]
    fig, ax = plt.subplots(figsize=(5.0, 2.6))
    ax.bar(range(5), g, yerr=err, capsize=3, color=cols, width=0.62,
           edgecolor="white", linewidth=0.6, error_kw=dict(lw=0.9, ecolor="0.25"))
    for i, v in enumerate(g):
        ax.text(i, v + (0.12 if v >= 0 else -0.22), f"{v:.2f}", ha="center",
                fontsize=7.5)
    ax.axhline(g[0], ls="--", lw=0.9, color="0.35")
    ax.axhline(0, lw=0.8, color="black")
    ax.set_xticks(range(5), labels, fontsize=7)
    ax.set_ylabel("Gain of ACE over HEFT (%)")
    ax.annotate("largest single effect", xy=(1, g[1]), xytext=(1.7, g[0] * 1.25),
                fontsize=7, color="#B03000",
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#B03000"))
    save(fig, "fig_protocol")


def fig_reassign():
    rows = load("factorial")
    modes = ["none", "reactive", "predictive"]
    mk = {"o": "o", "s": "s", "D": "D"}
    fig, ax = plt.subplots(figsize=(5.4, 2.8))
    y = np.arange(len(METHODS))[::-1]
    for mi, (mode, mkr, c) in enumerate(zip(modes, ["o", "s", "D"],
                                            ["#2C4F76", "#C8A02C", COL["ACE"]])):
        vals = [col(rows, m, "makespan", reassign=mode).mean() for m in METHODS]
        ax.scatter(vals, y + (mi - 1) * 0.0, marker=mkr, s=26, color=c,
                   edgecolor="white", linewidth=0.5, zorder=3,
                   label=mode.capitalize())
    for yy, m in zip(y, METHODS):
        v = [col(rows, m, "makespan", reassign=md).mean() for md in modes]
        ax.plot([min(v), max(v)], [yy, yy], color="0.6", lw=1.0, zorder=1)
    base = col(rows, "ACE", "makespan", reassign="none").mean()
    ax.axvline(base, ls="--", lw=0.9, color=COL["ACE"])
    ax.text(base, y[0] + 0.5, f"ACE, no reassignment ({base:.1f})", rotation=90,
            fontsize=6.6, color=COL["ACE"], va="bottom", ha="right")
    ax.set_yticks(y, METHODS)
    ax.set_xlabel("Makespan (model time units)")
    ax.legend(title="Reassignment", frameon=False, fontsize=7, title_fontsize=7,
              loc="lower right")
    save(fig, "fig_reassign")


def fig_tuning():
    s = json.load(open(ROOT / "results" / "processed" / "summary.json"))["tuning"]
    gammas = [0.10, 0.20, 0.30, 0.45, 0.60]
    wefts = [1.0, 1.3, 1.6, 2.0, 2.5]
    alphas = [0.15, 0.35, 0.60]
    lams = [2.0, 8.0, 32.0]
    A = np.array([[s["ACE"][f"{g}|{w}"] for w in wefts] for g in gammas])
    B = np.array([[s["LinUCB"][f"{a}|{l}"] for l in lams] for a in alphas])
    fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.5),
                           gridspec_kw=dict(width_ratios=[5, 3.2]))
    for a, Mx, xl, yl, xt, yt, ttl, rep, in zip(
            ax, [A, B],
            ["finish-time weight $w_{\\mathrm{eft}}$", "prior strength $\\lambda_0$"],
            ["base learning rate $\\gamma$", "exploration coefficient $\\alpha$"],
            [wefts, lams], [gammas, alphas],
            ["(a) ACE", "(b) LinUCB comparator"],
            [(2, 2), (1, 1)]):
        im = a.imshow(Mx, cmap="Blues", aspect="auto")
        for i in range(Mx.shape[0]):
            for j in range(Mx.shape[1]):
                a.text(j, i, f"{Mx[i, j]:.0f}", ha="center", va="center",
                       fontsize=6.6,
                       color="white" if Mx[i, j] > Mx.mean() else "black")
        bi = np.unravel_index(np.argmin(Mx), Mx.shape)
        a.add_patch(plt.Rectangle((bi[1] - .5, bi[0] - .5), 1, 1, fill=False,
                                  ec="#1E5E3A", lw=1.6, ls="--"))
        a.add_patch(plt.Rectangle((rep[1] - .5, rep[0] - .5), 1, 1, fill=False,
                                  ec="#B03000", lw=1.6))
        a.set_xticks(range(len(xt)), xt)
        a.set_yticks(range(len(yt)), yt)
        a.set_xlabel(xl)
        a.set_ylabel(yl)
        a.set_title(ttl, loc="left")
        a.grid(False)
        fig.colorbar(im, ax=a, fraction=0.046, pad=0.03).ax.tick_params(labelsize=6.5)
    fig.text(0.5, 1.03, "solid outline: configuration reported   "
                        "dashed outline: best cell of the sweep",
             ha="center", fontsize=7)
    save(fig, "fig_tuning")


def fig_noise():
    s = json.load(open(ROOT / "results" / "processed" / "summary.json"))["noise"]
    sig = sorted(float(k) for k in s)
    fig, ax = plt.subplots(figsize=(5.0, 2.7))
    for m in ("HEFT", "RAH", "LinUCB-C", "LinUCB-W", "ACE"):
        y = [s[str(x)][m]["red"] for x in sig]
        e = [s[str(x)][m]["red_sd"] / np.sqrt(12) for x in sig]
        ax.errorbar(sig, y, yerr=e, color=COL[m], marker=MARK[m], ms=4, lw=1.2,
                    capsize=2, label=("Proposed (ACE)" if m == "ACE" else m),
                    ls="--" if m == "HEFT" else "-")
    ax.axhline(0, color="0.4", lw=0.8)
    ax.set_xlabel("Profiling error $\\sigma$ (log-normal)")
    ax.set_ylabel("Makespan reduction vs. HEFT (%)")
    ax.legend(frameon=False, fontsize=7)
    save(fig, "fig_noise")


def fig_workflows():
    s = json.load(open(ROOT / "results" / "processed" / "summary.json"))
    per = s["structural"]["per_family"]
    fams = ["Montage", "CyberShake", "Epigenomics", "LIGO"]
    show = ["CPOP", "PEFT", "HEFT", "RAH", "LinUCB-W", "ACE"]
    fig, ax = plt.subplots(figsize=(6.0, 2.6))
    w = 0.13
    x = np.arange(len(fams))
    for i, m in enumerate(show):
        v = [per[f][m]["norm"] for f in fams]
        ax.bar(x + (i - len(show) / 2 + .5) * w, v, w, color=COL[m],
               label=("Proposed (ACE)" if m == "ACE" else m),
               edgecolor="white", linewidth=0.4)
    ax.axhline(1.0, ls="--", lw=0.9, color=COL["HEFT"])
    ax.set_xticks(x, [f + "-like" for f in fams])
    ax.set_ylabel("Makespan, normalised to HEFT")
    ax.set_ylim(0.80, max(per[f]["CPOP"]["norm"] for f in fams) * 1.08)
    ax.legend(ncol=3, frameon=False, fontsize=7)
    save(fig, "fig_workflows")


def fig_utilisation():
    rows = load("utilisation")
    show = ["HEFT", "RAH", "LinUCB-W", "ACE"]
    n = len(rows[0]["util_per_machine"])
    fig, ax = plt.subplots(figsize=(6.4, 2.4))
    w = 0.21
    x = np.arange(n)
    for i, m in enumerate(show):
        v = np.mean([r["util_per_machine"] for r in rows if r["method"] == m],
                    axis=0)
        ax.bar(x + (i - 1.5) * w, v, w, color=COL[m], label=m,
               edgecolor="none")
    ax.set_xticks(x[::2], (x + 1)[::2])
    ax.set_xlabel("VM index")
    ax.set_ylabel("Utilisation (%)")
    ax.set_ylim(0, 105)
    ax.legend(ncol=4, frameon=False, fontsize=7, loc="lower center")
    save(fig, "fig_utilisation")


ALL = {f.__name__: f for f in [fig_main_comparison, fig_scaling, fig_mechanism,
                               fig_warmup, fig_protocol, fig_reassign,
                               fig_tuning, fig_noise, fig_workflows,
                               fig_utilisation]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*", default=None)
    a = ap.parse_args()
    todo = a.only or list(ALL)
    for name in todo:
        key = name if name in ALL else f"fig_{name}"
        try:
            ALL[key]()
        except Exception as exc:                        # noqa: BLE001
            print(f"  !! {key}: {type(exc).__name__}: {exc}", file=sys.stderr)


if __name__ == "__main__":
    main()
