#!/usr/bin/env python3
"""Generate every LaTeX table in the paper from results/raw/*.json.

Writes .tex fragments to results/processed/ (one file per table) plus a
machine-readable summary results/processed/summary.json used by
scripts/check_consistency.py.

Usage:  python scripts/make_tables.py
"""
from __future__ import annotations
import json, sys
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "results" / "raw"
OUT = ROOT / "results" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

METHODS = ["CPOP", "PEFT", "HEFT", "LinUCB-C", "RAH", "LinUCB-W", "ACE"]
LABEL = {m: m for m in METHODS}
LABEL["ACE"] = r"\textbf{Proposed Method}"


def load(name):
    p = RAW / f"{name}.json"
    if not p.exists():
        raise FileNotFoundError(f"{p} missing -- run scripts/run_all.py first")
    return json.load(open(p))


def col(rows, method, key, **filt):
    sel = [r for r in rows if r.get("method") == method
           and all(r.get(k) == v for k, v in filt.items())]
    sel.sort(key=lambda r: r["seed"])
    return np.array([r[key] for r in sel], dtype=float)


def holm(pvals):
    """Holm-Bonferroni correction; returns adjusted p-values in input order."""
    order = np.argsort(pvals)
    adj = np.empty(len(pvals))
    prev = 0.0
    for rank, idx in enumerate(order):
        val = (len(pvals) - rank) * pvals[idx]
        prev = max(prev, min(val, 1.0))
        adj[idx] = prev
    return adj


def rank_biserial(x, y):
    """Rank-biserial correlation for a paired comparison (Kerby 2014)."""
    d = np.asarray(y) - np.asarray(x)
    d = d[d != 0]
    if len(d) == 0:
        return 0.0
    r = stats.rankdata(np.abs(d))
    return float((r[d > 0].sum() - r[d < 0].sum()) / r.sum())


def ci95(x):
    x = np.asarray(x, float)
    if len(x) < 2:
        return (float("nan"), float("nan"))
    return tuple(stats.t.interval(0.95, len(x) - 1, x.mean(), stats.sem(x)))


# --------------------------------------------------------------------------- #
def table_main(summary):
    rows = load("main")
    ace = col(rows, "ACE", "makespan")
    n = len(ace)
    lines, stat = [], {}
    pv = []
    for m in METHODS[:-1]:
        pv.append(stats.wilcoxon(col(rows, m, "makespan"), ace).pvalue)
    adj = holm(np.array(pv))

    body = []
    for k, m in enumerate(METHODS):
        v = col(rows, m, "makespan")
        get = lambda key: float(np.mean(col(rows, m, key)))
        gain = 100 * (v.mean() - ace.mean()) / v.mean() if m != "ACE" else None
        stat[m] = dict(makespan=float(v.mean()), sd=float(v.std(ddof=1)),
                       ci=ci95(v), energy=get("energy"), util=get("util"),
                       sigma=get("sigma_load"), delay=get("delay"),
                       matching=get("matching"), ms=get("wallclock_ms"),
                       gain=gain)
        if m != "ACE":
            stat[m]["p_raw"] = float(pv[k])
            stat[m]["p_holm"] = float(adj[k])
            stat[m]["rb"] = rank_biserial(ace, v)
            stat[m]["wins"] = int((ace < v).sum())
        g = "---" if gain is None else f"{gain:.2f}"
        body.append(
            f"{LABEL[m]} & {v.mean():.1f} & {v.std(ddof=1):.1f} & "
            f"{stat[m]['energy']:.1f} & {stat[m]['util']:.1f} & "
            f"{stat[m]['sigma']:.2f} & {stat[m]['delay']:.1f} & "
            f"{stat[m]['matching']:.3f} & {stat[m]['ms']:.0f} & {g} \\\\")
    fr = stats.friedmanchisquare(*[col(rows, m, "makespan") for m in METHODS])
    summary["main"] = dict(n_seeds=n, per_method=stat,
                           friedman_chi2=float(fr.statistic),
                           friedman_p=float(fr.pvalue))
    (OUT / "table_main.tex").write_text("\n".join(body) + "%\n")
    return summary


def table_factorial(summary):
    rows = load("factorial")
    body, stat = [], {}
    for m in METHODS:
        vals = {}
        for mode in ("none", "reactive", "predictive"):
            v = col(rows, m, "makespan", reassign=mode)
            vals[mode] = dict(mean=float(v.mean()), sd=float(v.std(ddof=1)))
        stat[m] = vals
        b = lambda x: f"\\textbf{{{x:.1f}}}" if m == "ACE" else f"{x:.1f}"
        body.append(f"{LABEL[m]} & {b(vals['none']['mean'])} & "
                    f"{b(vals['reactive']['mean'])} & {b(vals['predictive']['mean'])} \\\\")
    summary["factorial"] = dict(n_seeds=len(col(rows, "ACE", "makespan",
                                                reassign="none")),
                                per_method=stat)
    (OUT / "table_factorial.tex").write_text("\n".join(body) + "%\n")
    return summary


def table_protocol(summary):
    rows = load("protocol")
    names = {"full": ("Full protocol", "Access only to the profiled cost matrix $W$"),
             "P3": ("P3 disabled", "True slowdown $\\rho_j(t)$ for all machines"),
             "P1": ("P1 disabled", "Feedback before task completion"),
             "P2": ("P2 disabled", "Counterfactual reward information"),
             "P4": ("P4 disabled", "Local rather than global admission testing")}
    base = None
    body, stat = [], {}
    for c in ("full", "P3", "P1", "P2", "P4"):
        a = col(rows, "ACE", "makespan", condition=c)
        h = col(rows, "HEFT", "makespan", condition=c)
        per_seed = 100 * (h - a) / h                     # per-seed gain
        g, sd = float(per_seed.mean()), float(per_seed.std(ddof=1))
        lo, hi = ci95(per_seed)
        if c == "full":
            base = g
        stat[c] = dict(gain=g, sd=sd, ci=(lo, hi), delta=g - base,
                       ace=float(a.mean()), heft=float(h.mean()))
        lab, desc = names[c]
        d = "---" if c == "full" else f"${g - base:+.2f}$"
        body.append(f"{lab} & {desc} & ${g:.2f}$ & ${sd:.2f}$ & "
                    f"$[{lo:.2f},\\,{hi:.2f}]$ & {d} \\\\")
    summary["protocol"] = dict(n_seeds=len(col(rows, "ACE", "makespan",
                                               condition="full")),
                               per_condition=stat)
    (OUT / "table_protocol.tex").write_text("\n".join(body) + "%\n")
    return summary


def table_structural(summary):
    """Supplementary Table S7: per-family means and standard deviations."""
    rows = load("structural")
    fams = ["Montage", "CyberShake", "Epigenomics", "LIGO"]
    body, stat = [], {}
    for fam in fams:
        h = col(rows, "HEFT", "makespan", family=fam)
        a = col(rows, "ACE", "makespan", family=fam)
        per_seed = 100 * (h - a) / h
        lo, hi = ci95(per_seed)
        w = stats.wilcoxon(a, h)
        stat[fam] = dict(n=len(a), heft=float(h.mean()), heft_sd=float(h.std(ddof=1)),
                         ace=float(a.mean()), ace_sd=float(a.std(ddof=1)),
                         gain=float(per_seed.mean()), gain_sd=float(per_seed.std(ddof=1)),
                         ci=(lo, hi), p=float(w.pvalue),
                         ratio=float((a / h).mean()))
        for m in METHODS:
            v = col(rows, m, "makespan", family=fam)
            stat[fam][m] = dict(mean=float(v.mean()), sd=float(v.std(ddof=1)),
                                norm=float((v / h).mean()))
        body.append(f"{fam}-like & {len(a)} & {h.mean():.1f} $\\pm$ {h.std(ddof=1):.1f} & "
                    f"{a.mean():.1f} $\\pm$ {a.std(ddof=1):.1f} & "
                    f"{per_seed.mean():.2f} $\\pm$ {per_seed.std(ddof=1):.2f} & "
                    f"$[{lo:.2f},\\,{hi:.2f}]$ & {w.pvalue:.3f} \\\\")
    # family x method test on the normalised makespan
    kw = stats.kruskal(*[100 * (col(rows, "HEFT", "makespan", family=f)
                                - col(rows, "ACE", "makespan", family=f))
                         / col(rows, "HEFT", "makespan", family=f) for f in fams])
    summary["structural"] = dict(per_family=stat, kruskal_H=float(kw.statistic),
                                 kruskal_p=float(kw.pvalue))
    (OUT / "table_structural.tex").write_text("\n".join(body) + "%\n")
    return summary


def table_scaling(summary):
    rows = load("scaling")
    stat = {}
    for m in METHODS:
        stat[m] = {}
        for size in sorted({int(r["m"]) for r in rows}):
            sel = [r for r in rows if r["method"] == m and int(r["m"]) == size]
            stat[m][size] = dict(
                makespan=float(np.mean([r["makespan"] for r in sel])),
                sd=float(np.std([r["makespan"] for r in sel], ddof=1)),
                sigma=float(np.mean([r["sigma_load"] for r in sel])),
                ms=float(np.mean([r["wallclock_ms"] for r in sel])))
    summary["scaling"] = stat
    return summary


def table_noise(summary):
    rows = load("noise")
    stat = {}
    for sg in sorted({r["sigma"] for r in rows}):
        h = col(rows, "HEFT", "makespan", sigma=sg)
        stat[str(sg)] = {}
        for m in ("HEFT", "RAH", "LinUCB-C", "LinUCB-W", "ACE"):
            v = col(rows, m, "makespan", sigma=sg)
            per_seed = 100 * (h - v) / h
            p = stats.wilcoxon(v, h).pvalue if m != "HEFT" else 1.0
            stat[str(sg)][m] = dict(mean=float(v.mean()),
                                    red=float(per_seed.mean()),
                                    red_sd=float(per_seed.std(ddof=1)),
                                    p_vs_heft=float(p))
        a = col(rows, "ACE", "makespan", sigma=sg)
        for other in ("RAH", "LinUCB-W"):
            o = col(rows, other, "makespan", sigma=sg)
            stat[str(sg)][f"ACE_vs_{other}_p"] = float(stats.wilcoxon(a, o).pvalue)
    summary["noise"] = stat
    return summary


def table_tuning(summary):
    rows = load("tuning")
    ace = {}
    for r in [x for x in rows if x["kind"] == "ACE"]:
        ace.setdefault((r["gamma"], r["w_eft"]), []).append(r["makespan"])
    lin = {}
    for r in [x for x in rows if x["kind"] == "LinUCB-W"]:
        lin.setdefault((r["alpha"], r["lam0"]), []).append(r["makespan"])
    ace_m = {f"{k[0]}|{k[1]}": float(np.mean(v)) for k, v in ace.items()}
    lin_m = {f"{k[0]}|{k[1]}": float(np.mean(v)) for k, v in lin.items()}
    summary["tuning"] = dict(
        ACE=ace_m, LinUCB=lin_m,
        ace_best=min(ace_m.values()), ace_worst=max(ace_m.values()),
        ace_reported=ace_m["0.3|1.6"],
        lin_best=min(lin_m.values()), lin_worst=max(lin_m.values()),
        lin_reported=lin_m["0.35|8.0"],
        ace_spread=100 * (max(ace_m.values()) - min(ace_m.values())) / min(ace_m.values()),
        ace_above_best=100 * (ace_m["0.3|1.6"] - min(ace_m.values())) / min(ace_m.values()),
        lin_spread=100 * (max(lin_m.values()) - min(lin_m.values())) / min(lin_m.values()),
        lin_above_best=100 * (lin_m["0.35|8.0"] - min(lin_m.values())) / min(lin_m.values()),
        n_seeds=len(next(iter(ace.values()))))
    return summary


def table_mechanism(summary):
    d = load("mechanism")
    sp = np.array(d["spearman"])
    rec = np.array(d["recall3"])
    err = np.array(d["abs_err"])
    k = len(sp)
    dec = slice(int(0.9 * k), k)
    summary["mechanism"] = dict(
        n_completions=k,
        spearman_whole_run=float(sp.mean()), spearman_whole_run_sd=float(sp.std(ddof=1)),
        spearman_last_decile=float(sp[dec].mean()),
        spearman_last_decile_sd=float(sp[dec].std(ddof=1)),
        spearman_final=float(sp[-1]),
        recall3_whole_run=float(100 * rec.mean()), recall3_sd=float(100 * rec.std(ddof=1)),
        recall3_final=float(100 * rec[-1]),
        abs_err_first_decile=float(err[:k // 10].mean()),
        abs_err_last_decile=float(err[dec].mean()))
    return summary


def table_warmup(summary):
    rows = load("warmup")
    A = np.array([r["advantage"] for r in rows])
    firsts = []
    for a in A:
        pos = np.flatnonzero(a > 0)
        firsts.append(int(pos[0]) + 1 if len(pos) else len(a))
    summary["warmup"] = dict(n_seeds=len(rows),
                             breakeven_median=float(np.median(firsts)),
                             breakeven_mean=float(np.mean(firsts)),
                             final_advantage=float(A[:, -1].mean()),
                             final_advantage_sd=float(A[:, -1].std(ddof=1)))
    return summary


def main():
    summary = {}
    for fn in (table_main, table_factorial, table_protocol, table_structural,
               table_scaling, table_noise, table_tuning, table_mechanism,
               table_warmup):
        try:
            summary = fn(summary)
            print(f"  ok  {fn.__name__}")
        except FileNotFoundError as e:
            print(f"  SKIP {fn.__name__}: {e}", file=sys.stderr)
    (OUT / "summary.json").write_text(json.dumps(summary, indent=1))
    print(f"-> {(OUT / 'summary.json').relative_to(ROOT)}")


if __name__ == "__main__":
    main()
