#!/usr/bin/env python3
"""Verify that every number claimed in the manuscript matches the simulation
outputs in results/processed/summary.json.

Exits non-zero if any check fails, so it can be used in CI.

Usage:  python scripts/check_consistency.py [--tex paper/main.tex]
"""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SUM = ROOT / "results" / "processed" / "summary.json"

FAIL = 0


def _read_project(main: Path) -> str:
    """Read a manuscript and inline its \\input files, one level deep.

    The JPDC project splits the body across sections/, so checking main.tex
    alone would silently verify nothing.
    """
    if not main.exists():
        return ""
    text = main.read_text()
    for rel in re.findall(r"\\input\{([^}]+)\}", text):
        cand = (main.parent / rel)
        cand = cand if cand.suffix else cand.with_suffix(".tex")
        if cand.exists():
            text += "\n" + cand.read_text()
    return text


def _decimals(x):
    """Decimal places a value is typically quoted to in the manuscript."""
    return 0 if abs(x) >= 100 else (2 if abs(x) >= 10 else 3)


def check(label, got, want, tol=0.02, unit=""):
    """Compare a quoted value with the simulated one.

    The manuscript rounds; the tolerance therefore scales with magnitude so
    that a value printed to one decimal place is not flagged for the rounding
    the printing itself introduced.
    """
    global FAIL
    tol = max(tol, 0.5 * 10 ** -_decimals(want) if want else tol,
              abs(want) * 5e-4)
    ok = abs(got - want) <= tol
    print(f"  [{'ok ' if ok else 'FAIL'}] {label:52s} manuscript {want:9.3f}{unit}"
          f"   simulation {got:9.3f}{unit}")
    if not ok:
        FAIL += 1
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tex", default=str(ROOT / "paper" / "main.tex"))
    a = ap.parse_args()
    if not SUM.exists():
        sys.exit("run scripts/make_tables.py first")
    s = json.load(open(SUM))
    tex = _read_project(Path(a.tex))

    print("Derived quantities recomputed from the raw outputs")
    pm = s["main"]["per_method"]
    ace = pm["ACE"]["makespan"]

    # 1. every Gain value must follow from the two makespans
    for m, d in pm.items():
        if d.get("gain") is None:
            continue
        check(f"Gain of ACE over {m}", 100 * (d["makespan"] - ace) / d["makespan"],
              d["gain"], 0.005, "%")

    # 2. protocol deltas must follow from the gains
    pc = s["protocol"]["per_condition"]
    base = pc["full"]["gain"]
    for c, d in pc.items():
        check(f"Protocol delta, {c}", d["gain"] - base, d["delta"], 0.005, " pp")

    # 3. tuning spreads
    t = s["tuning"]
    check("ACE sweep spread", 100 * (t["ace_worst"] - t["ace_best"]) / t["ace_best"],
          t["ace_spread"], 0.005, "%")
    check("LinUCB sweep spread", 100 * (t["lin_worst"] - t["lin_best"]) / t["lin_best"],
          t["lin_spread"], 0.005, "%")

    # 4. numbers quoted in the manuscript text
    if tex:
        print("\nNumbers quoted in the manuscript text")
        rb = s.get("robustness", {})
        it = s.get("intensity", {})
        st = s["structural"]["per_family"]
        pats = {
            r"by ([\d.]+)\\% relative to HEFT": (pm["HEFT"]["gain"], "%"),
            r"([\d.]+)\\% relative to the resource-aware\s+heuristic":
                (pm["RAH"]["gain"], "%"),
            r"\$\\chi\^2\(6\)=([\d.]+)": (s["main"]["friedman_chi2"], ""),
            r"prior,? by ([\d.]+)\\%":
                (100 * (1 - pm["LinUCB-W"]["makespan"] / pm["RAH"]["makespan"]), "%"),
            r"matching score of ([\d.]+) confirms": (pm["ACE"]["matching"], ""),
            r"Planning time is ([\d.]+)\\,ms": (pm["ACE"]["ms"], " ms"),
            r"above HEFT\x27s ([\d.]+)\\,ms": (pm["HEFT"]["ms"], " ms"),
            
            r"median of ([\d]+) of 1000 completions":
                (s["warmup"]["breakeven_median"], ""),
            r"([\d.]+)\\pm0\.246":
                (s["mechanism"]["spearman_whole_run"], ""),
            r"from\s*\n?0\.76\\% in class to ([\d.]+)\\% under task-type":
                (rb.get("tasktype", {}).get("ace_rah", {}).get("gain", float("nan")), "%"),
            r"([\d.]+)\\% under two-sided\s*\n?variation":
                (rb.get("twosided", {}).get("ace_rah", {}).get("gain", float("nan")), "%"),
            r"([\d.]+)\\% at\s*\n?\$\\eta=4\.0\$":
                (it.get("4.0", {}).get("ace_rah", {}).get("gain", float("nan")), "%"),
        }
        for pat, (want, unit) in pats.items():
            mm = re.search(pat, tex)
            if mm:
                check(pat[:48], float(mm.group(1)), want, 0.02, unit)
            else:
                print(f"  [--  ] pattern not found: {pat[:48]}")

    print(f"\n{FAIL} failure(s)")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
