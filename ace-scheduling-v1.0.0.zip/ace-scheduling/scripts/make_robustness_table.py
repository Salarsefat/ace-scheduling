#!/usr/bin/env python3
"""Generate the robustness table (out-of-class perturbations + intensity sweep).

Writes results/processed/table_robustness.tex and merges the numbers into
results/processed/summary.json.

Usage:  python scripts/make_robustness_table.py
"""
from __future__ import annotations
import json
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "results" / "raw"
OUT = ROOT / "results" / "processed"


def col(rows, m, key, **f):
    sel = [r for r in rows if r.get("method") == m
           and all(r.get(k) == v for k, v in f.items())]
    sel.sort(key=lambda r: r["seed"])
    return np.array([r[key] for r in sel], float)


def cmp(base, cand):
    """Paired comparison: percentage reduction of cand relative to base."""
    g = 100.0 * (base - cand).mean() / base.mean()
    return dict(gain=float(g), p=float(stats.wilcoxon(cand, base).pvalue),
                wins=int((cand < base).sum()))


def block(rows, key, values):
    out = {}
    for v in values:
        f = {key: v}
        h, ra, lw, a = (col(rows, m, "makespan", **f)
                        for m in ("HEFT", "RAH", "LinUCB-W", "ACE"))
        out[str(v)] = dict(n=int(len(a)), ace_heft=cmp(h, a),
                           ace_rah=cmp(ra, a), lin_rah=cmp(ra, lw))
    return out


def fmt_p(p):
    return "$<$0.0001" if p < 1e-4 else f"{p:.4f}"


def cell(d):
    return f"{d['gain']:+.2f} ({fmt_p(d['p'])})"


def row(label, d):
    return (label + " & " + str(d["n"]) + " & " + cell(d["ace_heft"]) + " & "
            + cell(d["ace_rah"]) + " & " + cell(d["lin_rah"]) + r" \\")


def main():
    summary = json.load(open(OUT / "summary.json"))
    rob = block(json.load(open(RAW / "robustness.json")), "pert_mode",
                ["machine", "tasktype", "twosided"])
    inten = block(json.load(open(RAW / "intensity.json")), "intensity",
                  [0.5, 1.0, 2.0, 4.0])
    summary["robustness"] = rob
    summary["intensity"] = inten

    labels = {
        "machine": r"Machine-level, $\eta=2.0$ \emph{(in class)}",
        "tasktype": r"Task-type dependent \emph{(out of class)}",
        "twosided": r"Two-sided, speed-ups allowed \emph{(out of class)}",
    }
    lines = [row(labels[k], rob[k]) for k in ("machine", "tasktype", "twosided")]
    lines.append(r"\midrule")
    lines.append(r"\multicolumn{5}{@{}l}{\emph{Perturbation intensity"
                 r" $\eta$, machine-level}} \\")
    for k in ("0.5", "1.0", "2.0", "4.0"):
        lines.append(row(r"\quad $\eta=" + k + "$", inten[k]))

    (OUT / "table_robustness.tex").write_text("\n".join(lines) + "%\n")
    (OUT / "summary.json").write_text(json.dumps(summary, indent=1))
    print("-> results/processed/table_robustness.tex")
    for k, d in list(rob.items()) + list(inten.items()):
        print(f"  {k:10s} n={d['n']:2d}  ACE-HEFT {d['ace_heft']['gain']:+.2f}  "
              f"ACE-RAH {d['ace_rah']['gain']:+.2f} (p={d['ace_rah']['p']:.4f})  "
              f"LinUCB-RAH {d['lin_rah']['gain']:+.2f} (p={d['lin_rah']['p']:.4f})")


if __name__ == "__main__":
    main()
