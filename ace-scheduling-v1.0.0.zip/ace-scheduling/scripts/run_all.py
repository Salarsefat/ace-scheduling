#!/usr/bin/env python3
"""Run every experiment in the paper and write raw results to results/raw/.

Usage
-----
    python scripts/run_all.py --all
    python scripts/run_all.py --exp main protocol
    python scripts/run_all.py --all --quick     # small seed counts, for smoke tests

Every experiment is deterministic: the seed lists are fixed in SEEDS below and
each instance is built from its seed alone.  Re-running overwrites the JSON for
that experiment only, so experiments can be re-run individually.
"""
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ace.experiments import Instance, run_one, METHODS          # noqa: E402
from ace.scheduler import Protocol                              # noqa: E402

RAW = ROOT / "results" / "raw"
RAW.mkdir(parents=True, exist_ok=True)

SEEDS = dict(main=list(range(30)), factorial=list(range(10)),
             robustness=list(range(20)), intensity=list(range(12)),
             protocol=list(range(12)), structural=list(range(6)),
             scaling=list(range(10)), noise=list(range(12)),
             tuning=list(range(500, 508)))
M_MAIN = 1000
SIZES = [100, 250, 500, 750, 1000]
FAMILIES = ["Montage", "CyberShake", "Epigenomics", "LIGO"]
SIGMAS = [0.0, 0.2, 0.4, 0.7]
INTENSITIES = [0.5, 1.0, 2.0, 4.0]
PERT_MODES = ["machine", "tasktype", "twosided"]
CORE = ["HEFT", "RAH", "LinUCB-C", "LinUCB-W", "ACE"]
GAMMAS = [0.10, 0.20, 0.30, 0.45, 0.60]
WEFTS = [1.0, 1.3, 1.6, 2.0, 2.5]
ALPHAS = [0.15, 0.35, 0.60]
LAM0S = [2.0, 8.0, 32.0]


def _save(name, obj):
    p = RAW / f"{name}.json"
    with open(p, "w") as f:
        json.dump(obj, f)
    print(f"  -> {p.relative_to(ROOT)}  ({p.stat().st_size/1024:.0f} kB)")


def _slim(r):
    """Drop the bulky per-task vectors from a stored record."""
    return {k: v for k, v in r.items()
            if k not in ("assign", "trace", "finish_sorted", "util_per_machine")}


# --------------------------------------------------------------------------- #
def exp_main(seeds):
    """Table 5 / Fig. 2: seven methods, m = 1000, paired seeds."""
    out = []
    for s in seeds:
        inst = Instance(s, m=M_MAIN)
        for name in METHODS:
            t0 = time.time()
            r = run_one(name, inst)
            r["wallclock_ms"] = 1000 * (time.time() - t0)
            out.append(_slim(r))
    return out


def exp_utilisation(seeds):
    """Supplementary Fig. S3: per-machine utilisation for four methods."""
    out = []
    for s in seeds:
        inst = Instance(s, m=M_MAIN)
        for name in ["HEFT", "RAH", "LinUCB-W", "ACE"]:
            r = run_one(name, inst)
            out.append(dict(method=name, seed=s,
                            util_per_machine=r["util_per_machine"]))
    return out


def exp_scaling(seeds):
    """Fig. 3: makespan, load dispersion and planning time versus m."""
    out = []
    for m in SIZES:
        for s in seeds:
            inst = Instance(s, m=m)
            for name in METHODS:
                t0 = time.time()
                r = run_one(name, inst)
                r["wallclock_ms"] = 1000 * (time.time() - t0)
                out.append(_slim(r))
    return out


def exp_factorial(seeds):
    """Supplementary Table S6 / Fig. S1: allocator x reassignment mode."""
    out = []
    for s in seeds:
        inst = Instance(s, m=M_MAIN)
        for mode in ("none", "reactive", "predictive"):
            for name in METHODS:
                r = run_one(name, inst, reassign=mode)
                r["reassign"] = mode
                out.append(_slim(r))
    return out


def exp_protocol(seeds):
    """Table 6 / Fig. 5: relax each event-consistency condition in turn."""
    conds = {"full": Protocol(), "P3": Protocol(p3=False),
             "P1": Protocol(p1=False), "P2": Protocol(p2=False),
             "P4": Protocol(p4=False)}
    out = []
    for s in seeds:
        inst = Instance(s, m=M_MAIN)
        for cname, proto in conds.items():
            mode = "predictive" if cname == "P4" else "none"
            for name in ("HEFT", "ACE"):
                r = run_one(name, inst, protocol=proto, reassign=mode)
                r["condition"] = cname
                out.append(_slim(r))
    return out


def exp_tuning(seeds):
    """Supplementary Fig. S2: hyperparameter sweeps on held-out tuning seeds."""
    out = []
    for s in seeds:
        inst = Instance(s, m=M_MAIN)
        for g in GAMMAS:
            for w in WEFTS:
                r = run_one("ACE", inst, gamma=g, w_eft=w)
                out.append(dict(kind="ACE", seed=s, gamma=g, w_eft=w,
                                makespan=r["makespan"]))
        for a in ALPHAS:
            for l in LAM0S:
                r = run_one("LinUCB-W", inst, alpha=a, lam0=l)
                out.append(dict(kind="LinUCB-W", seed=s, alpha=a, lam0=l,
                                makespan=r["makespan"]))
    return out


def exp_noise(seeds):
    """Fig. 6: makespan reduction relative to HEFT under profiling error."""
    out = []
    for sg in SIGMAS:
        for s in seeds:
            inst = Instance(s, m=M_MAIN, profiling_sigma=sg)
            for name in ("HEFT", "RAH", "LinUCB-C", "LinUCB-W", "ACE"):
                r = run_one(name, inst)
                r["sigma"] = sg
                out.append(_slim(r))
    return out


def exp_structural(seeds):
    """Fig. 7 and Supplementary Table S7: four structural mimics."""
    out = []
    for fam in FAMILIES:
        for s in seeds:
            inst = Instance(s, m=600, family=fam)
            for name in METHODS:
                r = run_one(name, inst)
                r["family"] = fam
                out.append(_slim(r))
    return out


def exp_mechanism(seed=0):
    """Fig. 4: learned correction against the true slowdown, ONE traced run
    (seed 0).  The Section 4.1.1 statistics are within-run dispersions
    across the completions of this single trace, not across-seed values."""
    inst = Instance(seed, m=M_MAIN)
    r = run_one("ACE", inst, trace=True)
    rows = r.pop("trace")
    rho = np.stack([x["rho"] for x in rows])
    hat = np.stack([x["rho_hat"] for x in rows])
    n = rho.shape[1]
    sp = np.array([stats.spearmanr(hat[k], rho[k]).statistic for k in range(len(rows))])
    sp = np.nan_to_num(sp, nan=0.0)
    err = np.abs(hat - rho).mean(axis=1)
    # recall at 3 against the ground-truth ranking of rho at the END of the run
    final = np.array(r["rho_final"])
    top_true = set(np.argsort(-final)[:3].tolist())
    rec = np.array([len(top_true & set(np.argsort(-hat[k])[:3].tolist())) / 3.0
                    for k in range(len(rows))])
    return dict(seed=seed, spearman=sp.tolist(), abs_err=err.tolist(),
                recall3=rec.tolist(), rho=rho[:, :].tolist(),
                rho_hat=hat.tolist(), rho_final=final.tolist(),
                makespan=r["makespan"])


def exp_warmup(seeds):
    """Supplementary Fig. S4: cumulative advantage of ACE over its prior (RAH).

    Advantage A(k) is the difference between the times at which the k-th task
    completes under RAH and under ACE on the same instance.  A(m) is exactly
    the makespan difference.
    """
    out = []
    for s in seeds:
        inst = Instance(s, m=M_MAIN)
        curves = {}
        for name in ("RAH", "ACE"):
            r = run_one(name, inst, trace=False)
            curves[name] = r["finish_sorted"]
        a = np.array(curves["RAH"]) - np.array(curves["ACE"])
        out.append(dict(seed=s, advantage=a.tolist()))
    return out


def exp_robustness(seeds):
    """Is the ordering stable outside ACE's own hypothesis class?

    Assumption (A2) makes the environment's perturbation exactly a
    machine-level multiplicative factor, which is the hypothesis class of the
    one-scalar-per-machine correction.  Two out-of-class environments are run
    at the same intensity: one in which the slowdown differs by task type on
    the same machine, and one in which log rho is a zero-mean process so that
    machines may run faster than profiled.
    """
    out = []
    for mode in PERT_MODES:
        for s in seeds:
            inst = Instance(s, m=M_MAIN, pert_mode=mode)
            for name in CORE:
                r = run_one(name, inst)
                r["pert_mode"] = mode
                out.append(_slim(r))
    return out


def exp_intensity(seeds):
    """Sweep the perturbation intensity, the variable ACE exists to correct."""
    out = []
    for k in INTENSITIES:
        for s in seeds:
            inst = Instance(s, m=M_MAIN, intensity=k)
            for name in CORE:
                r = run_one(name, inst)
                r["intensity"] = k
                out.append(_slim(r))
    return out


EXPERIMENTS = dict(main=exp_main, robustness=exp_robustness,
                   intensity=exp_intensity, scaling=exp_scaling, factorial=exp_factorial,
                   protocol=exp_protocol, tuning=exp_tuning, noise=exp_noise,
                   structural=exp_structural, utilisation=exp_utilisation,
                   warmup=exp_warmup)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--exp", nargs="*", default=None,
                    help="subset of: " + ", ".join(list(EXPERIMENTS) + ["mechanism"]))
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--quick", action="store_true",
                    help="use 3 seeds everywhere (smoke test, NOT for results)")
    args = ap.parse_args()

    todo = list(EXPERIMENTS) + ["mechanism"] if args.all else (args.exp or [])
    if not todo:
        ap.error("give --all or --exp NAME [NAME ...]")

    for name in todo:
        t0 = time.time()
        print(f"[run] {name}")
        try:
            if name == "mechanism":
                _save("mechanism", exp_mechanism(0))
            else:
                key = {"utilisation": "main", "warmup": "main"}.get(name, name)
                seeds = SEEDS.get(key, SEEDS["main"])
                if args.quick:
                    seeds = seeds[:3]
                _save(name, EXPERIMENTS[name](seeds))
        except Exception as exc:                      # noqa: BLE001
            print(f"  !! {name} failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            raise
        print(f"  done in {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
