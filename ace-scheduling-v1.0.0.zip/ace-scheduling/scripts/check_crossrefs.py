#!/usr/bin/env python3
"""Verify hand-typed cross-document references between the paper and its
supplement.

The manuscript and the supplement compile as separate LaTeX documents, so
strings such as "Supplementary Table S6" in the main text and "Table 5 of the
main text" in the supplement are plain text that LaTeX never checks. Renumbering
either document silently breaks them. This script reads both compiled PDFs,
builds the real number-to-caption maps, and checks every such string.

Usage:  python scripts/check_crossrefs.py [--paper paper]
Exits non-zero on any mismatch, so it can run in CI alongside
check_consistency.py.
"""
from __future__ import annotations
import argparse
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FAIL = 0


def pdftext(path: Path) -> str:
    if not path.exists():
        print(f"[skip] {path} not found; this check needs the compiled paper "
              f"(run `make paper` after adding the paper/ sources).")
        sys.exit(0)
    return subprocess.run(["pdftotext", str(path), "-"], capture_output=True,
                          text=True, check=True).stdout


def flatten(text: str) -> str:
    """Collapse newlines so captions that wrap are still matchable."""
    return re.sub(r"\s+", " ", text)


def captions(text: str, pattern: str) -> dict[str, str]:
    """Map a float number to the opening words of its caption."""
    out = {}
    for m in re.finditer(pattern, flatten(text)):
        out.setdefault(m.group(1), m.group(2).strip())
    return out


def check(label: str, ok: bool, detail: str = "") -> None:
    global FAIL
    print(f"  [{'ok ' if ok else 'FAIL'}] {label}{('  ' + detail) if detail else ''}")
    if not ok:
        FAIL += 1


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--paper", default="paper")
    a = ap.parse_args()
    base = ROOT / a.paper
    main_txt = pdftext(base / "main.pdf")
    supp_txt = pdftext(base / "supplementary" / "supplementary.pdf")

    main_tabs = captions(main_txt, r"Table (\d+)\. (.{0,60})")
    main_figs = captions(main_txt, r"Fig(?:ure|\.) (\d+)\. (.{0,60})")
    supp_tabs = captions(supp_txt, r"Table (S\d+)\. (.{0,60})")
    supp_figs = captions(supp_txt, r"Fig(?:ure|\.) (S\d+)\. (.{0,60})")

    print(f"main: {len(main_tabs)} tables, {len(main_figs)} figures | "
          f"supplement: {len(supp_tabs)} tables, {len(supp_figs)} figures\n")

    # ---- every "Supplementary Table Sn / Fig. Sn" in the main text exists ----
    print("Main text -> supplement")
    for kind, refs, have in (("Table", set(re.findall(r"Supplementary Tables?~?\s?(S\d+)", flatten(main_txt))), supp_tabs),
                             ("Table", set(re.findall(r"Supplementary Tables? S\d+ and~?\s?(S\d+)", flatten(main_txt))), supp_tabs),
                             ("Fig.", set(re.findall(r"Supplementary Figs?(?:ure)?\.?~?\s?(S\d+)", flatten(main_txt))), supp_figs)):
        for r in sorted(refs):
            check(f"Supplementary {kind} {r}", r in have,
                  f"-> {have.get(r, 'DOES NOT EXIST')[:52]}")

    # ---- every "of the main text" pointer in the supplement exists -----------
    print("\nSupplement -> main text")
    for r in sorted(set(re.findall(r"Table (\d+) of the main text", flatten(supp_txt)))):
        check(f"Table {r} of the main text", r in main_tabs,
              f"-> {main_tabs.get(r, 'DOES NOT EXIST')[:52]}")
    for r in sorted(set(re.findall(r"Fig(?:ure|\.) (\d+) of the main text", flatten(supp_txt)))):
        check(f"Fig. {r} of the main text", r in main_figs,
              f"-> {main_figs.get(r, 'DOES NOT EXIST')[:52]}")

    # ---- equation pointers: the number must be within range and displayed ----
    eqs = {int(x) for x in re.findall(r"\((\d+)\)\s*$", main_txt, flags=re.M)}
    hi = max(eqs) if eqs else 0
    for r in sorted({int(x) for x in re.findall(r"Eq\. \((\d+)\) of the main text", flatten(supp_txt))}):
        check(f"Eq. ({r}) of the main text", r in eqs,
              f"main text numbers equations 1..{hi}")

    # ---- section pointers -----------------------------------------------------
    # Section numbers come from the .aux, not the extracted text: pdftotext
    # sometimes merges a heading with the line above it.
    aux = (base / "main.aux")
    secs = set(re.findall(r"\\newlabel\{sec:[^}]*\}\{\{(\d+(?:\.\d+)?)\}",
                          aux.read_text())) if aux.exists() else set()
    secs |= set(re.findall(r"^(\d+(?:\.\d+)?)\s+[A-Z]", main_txt, flags=re.M))
    for r in sorted(set(re.findall(r"Section (\d+(?:\.\d+)?) of the main text", flatten(supp_txt)))):
        check(f"Section {r} of the main text", r in secs)

    print(f"\n{FAIL} failure(s)")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
