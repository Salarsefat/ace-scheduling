# Implementation notes

This document records (1) the provenance of every number in the repository,
(2) the eleven implementation decisions the paper's model leaves open, and
(3) behaviours of the implementation that a careful reader should know about.
The paper's internal-validity section refers to items (2) and (3).

## 1. Provenance

Every number, table and figure in the paper is produced by the code in this
repository. Nothing in `results/` is estimated, interpolated or hand-entered:
`results/raw/*.json` are the direct simulation outputs for the fixed seed
lists in `scripts/run_all.py`, and `results/processed/` and `figures/` are
derived from them by `scripts/make_tables.py`, `scripts/make_robustness_table.py`
and `scripts/make_figures.py`. The pipeline is deterministic: re-running any
experiment with the pinned dependency versions regenerates the committed raw
JSON bit-for-bit, and `scripts/check_consistency.py` verifies the manuscript's
quoted values against `results/processed/summary.json`.

**History.** An earlier draft of the manuscript reported substantially larger
effects. This implementation, written to the model's specification, could not
reproduce those numbers, and the manuscript was revised so that every result
it reports is exactly what this released code produces under the released
seeds. The revised paper also adopts this implementation's diagnostic
findings (the topology dependence, the two-window rank-agreement statistics,
and the degenerate reassignment working set) and discusses them as such.

## 2. The eleven fixed decisions

The paper's model leaves eleven implementation details open. Each was fixed
once, before any result was produced, and is recorded in
`config/default.yaml` (marked `RECONSTRUCTED`).

| # | Item | Choice | Risk |
|---|---|---|---|
| R1 | **Placement policy** | Estimate uses the machine's append point; commit uses the earliest insertion slot fitting the realised duration | **High — see Section 4 below** |
| R2 | Machine capability distributions | class-conditional uniforms, `ace/platform.py` | medium |
| R3 | Layer-width rule | w ~ U(0.6·cap, cap), cap = min(100, max(n, ceil(m/3))) | low: reproduces the depth/width statistics of Supplementary Tables S3 and S7 |
| R4 | Task-demand distribution | type drawn uniformly, then demands consistent with Eq. (1) | medium |
| R5 | Base workload ω_i | U(60, 140) | low |
| R6 | Perturbation parameters | drift/volatility/episode rates in `ace/perturbation.py`; severity chosen to match the paper's description, not any result | **high** |
| R7 | Perturbation index | global dispatch counter, so realisations are identical across allocators | low: required by the paired design (Section 4.0.2) |
| R8 | Data volumes | scaled so mean communication = CCR × mean W | low |
| R9 | P2-disabled semantics | reward denominator is the minimum over machines of the realised duration | medium |
| R10 | Checkpoint guard | skip a checkpoint with fewer pending tasks than machines | low; see Section 3 |
| R11 | Warm-up curve | A(k) = difference in the time at which the k-th task completes | low |

## 3. Behaviours a reader should know

* **P3 disabled means the correction is inert.** When condition P3 is
  relaxed, every allocator's duration estimate becomes the oracle
  `W_ij · rho_j(t)` (`estimated_duration` in `ace/allocators.py`), so ACE
  coincides with RAH under oracle durations and the learned correction does
  not influence any decision in that arm. The residual gain in the P3-off
  row of Table 6 is therefore the resource-aware prior's contribution under
  oracle information.
* **The three reassignment modes coincide exactly.** With decision R10 and
  the measured working set at m = 1000 (median 2, maximum 7 pending tasks
  against n = 34 machines), the guard fires at every checkpoint and no move
  is ever attempted; `results/raw/factorial.json` shows the three modes are
  bit-identical, which is what Section 4.1.3 of the paper reports.
* **The P4 projection covers dispatched-but-not-started tasks.** `_project`
  in `ace/scheduler.py` re-projects the makespan over tasks already assigned
  whose start lies in the future; tasks not yet dispatched are outside the
  projection. Given the empty working set above, this has no effect on any
  released number.
* **The mechanism trace is a single run.** Fig. 4 and the Section 4.1.1
  rank-agreement statistics come from one traced run (seed 0); the ± values
  are within-run dispersions across completions, not across-seed statistics.
  Rank agreement depends strongly on the averaging window (0.638 whole-run
  vs 0.864 last-decile on that trace), which is why both windows are drawn.
* **The LinUCB context has 15 features of which 14 are distinct.** Feature
  index 11 duplicates index 4 (`1 − W_ij / max_l W_il`); the ridge prior
  keeps the design matrix invertible despite the collinearity. It is
  preserved as-is because the released results were produced with it.

## 4. R1 is the decision that matters

The model says start times use the "earliest insertion slot". Implemented
literally — search for a gap that fits the *estimated* duration, commit the
*realised* one — the result is pathological: small gaps look usable to a
scheduler that underestimates durations, so earliest-finish-time selection is
drawn towards congested machines. Measured on one seed (m = 1000):

| Placement policy | HEFT makespan | HEFT utilisation | ACE gain over HEFT |
|---|---|---|---|
| Literal insertion | 10 054 | 50.5 % | 49.4 % |
| Insertion + reservation-miss fallback | 12 800 | 39.9 % | 60.2 % |
| Conservative estimate, opportunistic commit (**used**) | 5 156 | 96.5 % | 1.81 % |

Only the third is consistent with the utilisation this and comparable studies
report, which is why it is the released default; the paper's internal-validity
section discusses exactly this sensitivity, and `run_schedule` exposes the
policy through the `conservative_estimate` flag so it can be varied.

## 5. Environment

Python 3.12.3, NumPy 2.4.4, SciPy 1.17.1, Matplotlib 3.10.8 (pinned in
`requirements.txt`), single CPU core, no network access after installation.
Full pipeline: 2 291 scheduler runs across 12 experiments, ≈ 15 minutes.
