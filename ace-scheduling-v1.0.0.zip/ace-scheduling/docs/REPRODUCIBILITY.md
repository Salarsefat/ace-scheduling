# Reproducibility matrix

Every number, figure and table in the paper maps to a command. All commands are
run from the repository root and use relative paths.

| Paper item | Command | Input | Output |
|---|---|---|---|
| Table 5 (main comparison) | `python scripts/run_all.py --exp main` then `python scripts/make_tables.py` | seeds 0–29 | `results/raw/main.json`, `results/processed/table_main.tex` |
| Table 6 (protocol ablation) | `python scripts/run_all.py --exp protocol` then `make_tables.py` | seeds 0–11 | `results/raw/protocol.json`, `table_protocol.tex` |
| Table 7 (robustness + intensity) | `python scripts/run_all.py --exp robustness intensity` then `python scripts/make_robustness_table.py` | seeds 0–19, 0–11 | `results/raw/{robustness,intensity}.json`, `table_robustness.tex` |
| Supp. Table S6 (factorial) | `python scripts/run_all.py --exp factorial` then `make_tables.py` | seeds 0–9 | `results/raw/factorial.json`, `table_factorial.tex` |
| Supp. Table S7 (per-family) | `python scripts/run_all.py --exp structural` then `make_tables.py` | seeds 0–5 × 4 families | `results/raw/structural.json`, `table_structural.tex` |
| Fig. 2 (main comparison) | `python scripts/make_figures.py --only fig_main_comparison` | `results/raw/main.json` | `figures/fig_main_comparison.pdf` |
| Fig. 3 (scaling) | `python scripts/run_all.py --exp scaling` then `make_figures.py --only fig_scaling` | seeds 0–9 × 5 sizes | `figures/fig_scaling.pdf` |
| Fig. 4 (correction behaviour) | `python scripts/run_all.py --exp mechanism` then `make_figures.py --only fig_mechanism` | seed 0, one traced run | `figures/fig_mechanism.pdf` |
| Fig. 5 (protocol) | `make_figures.py --only fig_protocol` | `results/processed/summary.json` | `figures/fig_protocol.pdf` |
| Fig. 6 (profiling error) | `python scripts/run_all.py --exp noise` then `make_figures.py --only fig_noise` | seeds 0–11 × 4 σ | `figures/fig_noise.pdf` |
| Fig. 7 (workflow families) | `make_figures.py --only fig_workflows` | `results/processed/summary.json` | `figures/fig_workflows.pdf` |
| Supp. Figs. S1–S4 | `make_figures.py --only fig_reassign fig_tuning fig_utilisation fig_warmup` | corresponding raw JSON | `figures/fig_*.pdf` |
| Fig. 1 (method overview) | none | — | drawn in TikZ inside the manuscript source |
| Every quoted number | `python scripts/check_consistency.py --tex paper/main.tex` | `summary.json`, manuscript source | pass/fail report |
| Everything at once | `make all` (add `make full` once `paper/` is present) | — | results, tables, figures, tests |

## Expected outputs

`make all` takes roughly 15 minutes on one core and writes 12 JSON files to
`results/raw/` (about 1.1 MB), `results/processed/summary.json`, five LaTeX
table bodies, and ten vector PDFs in `figures/`, then runs the sanity tests.
`make full` additionally compiles the manuscript and runs the consistency
checks; both extra steps require a `paper/` directory that is not part of this
repository. The consistency check prints one line per verified quantity and
exits non-zero on any mismatch.

## Computational requirements

One CPU core, under 1 GB of memory, no GPU, no network access after
installation. Total 2 291 scheduler runs across 12 experiments. Individual
experiments range from 1 second (`mechanism`) to about 150 seconds
(`robustness`); run them separately with `--exp NAME` if a single long job is
inconvenient.

## Random-seed handling

One integer seed fixes the platform, the workflow, the profiled cost matrix,
the data volumes and the entire realisation of the perturbation process. The
seed lists are hard-coded in `scripts/run_all.py` and documented in
`config/default.yaml`. The perturbation is indexed by the global dispatch
counter rather than by simulated time, so its realisation is identical across
allocators for a given seed; this is what makes the paired statistics valid.
Tuning seeds (500–507) are disjoint from every evaluation seed.

## Troubleshooting

* **`ModuleNotFoundError: ace`** — run commands from the repository root, or
  set `PYTHONPATH=.`; the scripts insert the root on `sys.path` themselves.
* **Results differ slightly from the paper** — check NumPy and SciPy versions
  against `requirements.txt`. Different BLAS builds can change the last digit
  of the LinUCB matrix updates. The reported significance levels are not
  sensitive to this, but exact makespans can move in the third decimal.
* **`make paper` fails or is skipped** — the manuscript sources live outside
  this repository; add them under `paper/` (with `latexmk`, `tikz`,
  `booktabs`, `algorithm`, `algpseudocode` and `cleveref` available) and rerun.
* **A single experiment is slow** — `--quick` reduces every experiment to
  three seeds. Its output is a smoke test and must not be reported.
