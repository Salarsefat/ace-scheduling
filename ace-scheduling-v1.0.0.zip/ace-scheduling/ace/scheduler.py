"""Core scheduling engine: precedence-safe ready list, insertion-based
placement, deferred feedback, checkpoint reassignment and metrics.

Implements Algorithm 1 and Equations (4)-(17) of the manuscript.

RECONSTRUCTION NOTE -- estimated versus realised duration
---------------------------------------------------------
The manuscript requires (P3) that start and finish *estimates* never use the
true W_ij rho_j(t), while the schedule itself must respect the non-overlap
constraint Eq. (7) with the *realised* durations.  These two requirements are
reconciled here as follows:

  1. The candidate start S_ij used inside the estimate F~_ij (Eq. 9) is found
     by searching for the earliest insertion slot able to hold the *estimated*
     duration.  It therefore contains no information about rho.
  2. Once j* has been chosen, the task is committed by searching again on j*
     for the earliest slot able to hold the *realised* duration.  If the task
     overruns its estimate the placement slips, exactly as it would on a real
     platform.

This keeps P3 intact, keeps the schedule feasible, and makes overrun visible in
the makespan rather than hidden by an infeasible timeline.
"""
from __future__ import annotations
import heapq
import numpy as np

from .platform import Platform
from .workload import Workflow

BIG = float("inf")


# --------------------------------------------------------------------------- #
#  Machine timelines
# --------------------------------------------------------------------------- #
class Timeline:
    """Busy intervals of one machine, kept sorted by start time."""

    __slots__ = ("iv",)

    def __init__(self):
        self.iv = []                      # list of [start, finish]

    def earliest_slot(self, ready: float, dur: float) -> float:
        """Earliest start >= ready at which an interval of length dur fits."""
        if dur <= 0:
            dur = 1e-12
        t = ready
        for s, f in self.iv:
            if f <= t:
                continue
            if s - t >= dur:              # gap before this interval is enough
                return t
            t = max(t, f)
        return t

    def fits(self, start: float, dur: float) -> bool:
        """True if [start, start+dur) overlaps no committed interval."""
        end = start + dur
        for a, b in self.iv:
            if a < end and start < b:
                return False
        return True

    def append_point(self, ready: float) -> float:
        return max(ready, max((f for _, f in self.iv), default=0.0))

    def insert(self, start: float, dur: float) -> None:
        self.iv.append([start, start + dur])
        self.iv.sort(key=lambda x: x[0])

    def busy(self) -> float:
        return sum(f - s for s, f in self.iv)

    def clear(self) -> None:
        self.iv = []

    def drop_after(self, t: float) -> None:
        """Remove every interval that has not started by time t."""
        self.iv = [x for x in self.iv if x[0] <= t]


# --------------------------------------------------------------------------- #
#  Protocol conditions (Section 3.3.1)
# --------------------------------------------------------------------------- #
class Protocol:
    """Event-consistency conditions P1-P4 as independently toggleable flags."""

    def __init__(self, p1=True, p2=True, p3=True, p4=True):
        self.p1, self.p2, self.p3, self.p4 = p1, p2, p3, p4

    def label(self):
        off = [f"P{k}" for k, v in enumerate([self.p1, self.p2, self.p3, self.p4], 1)
               if not v]
        return "full" if not off else "+".join(off) + " off"


# --------------------------------------------------------------------------- #
#  Priorities (Eq. 8) and the precedence-safe ready list (Algorithm 1)
# --------------------------------------------------------------------------- #
def upward_rank(wf: Workflow, W: np.ndarray, cbar: np.ndarray) -> np.ndarray:
    """HEFT upward rank, computed in reverse topological order (Eq. 8)."""
    wbar = W.mean(axis=1)
    r = np.zeros(wf.m)
    for i in range(wf.m - 1, -1, -1):
        best = 0.0
        for k in wf.succs[i]:
            best = max(best, cbar[(i, k)] + r[k])
        r[i] = wbar[i] + best
    return r


def downward_rank(wf: Workflow, W: np.ndarray, cbar: np.ndarray) -> np.ndarray:
    wbar = W.mean(axis=1)
    d = np.zeros(wf.m)
    for i in range(wf.m):
        best = 0.0
        for p in wf.preds[i]:
            best = max(best, d[p] + wbar[p] + cbar[(p, i)])
        d[i] = best
    return d


def optimistic_cost_table(wf: Workflow, W: np.ndarray, cbar: np.ndarray) -> np.ndarray:
    """PEFT optimistic cost table (Arabnejad and Barbosa), vectorised over j.

    OCT[i,j] = max_{k in succ(i)} min_{jj} ( OCT[k,jj] + W[k,jj]
                                             + c_ik * [jj != j] ).
    The inner minimisation is computed in O(n) per edge by noting that
    min_{jj != j} v_k[jj] is the global minimum unless j attains it, in which
    case it is the second smallest value.
    """
    m, n = W.shape
    oct_ = np.zeros((m, n))
    for i in range(m - 1, -1, -1):
        if not wf.succs[i]:
            continue
        best = np.zeros(n)
        for k in wf.succs[i]:
            v = oct_[k] + W[k]
            o = np.argsort(v)[:2]
            m1, m2 = v[o[0]], v[o[1]] if n > 1 else v[o[0]]
            excl = np.full(n, m1)
            excl[o[0]] = m2                      # min over jj != j
            c = cbar[(i, k)]
            best = np.maximum(best, np.minimum(v, excl + c))
        oct_[i] = best
    return oct_


# --------------------------------------------------------------------------- #
#  The scheduling loop (Algorithm 1)
# --------------------------------------------------------------------------- #
def run_schedule(wf: Workflow, plat: Platform, W: np.ndarray, allocator,
                 pert, protocol: Protocol, W_true: np.ndarray = None,
                 reassign_mode: str = "none",
                 checkpoints: int = 30, theta_imb: float = 1.18,
                 theta_bal: float = 0.12, move_budget: int = 6,
                 conservative_estimate: bool = True, trace: bool = False):
    """Run one workflow to completion and return a result dictionary."""
    m, n = W.shape
    if W_true is None:
        W_true = W          # no profiling error: the scheduler sees the truth
    cbar = {}
    for (a, b) in wf.edges:
        cbar[(a, b)] = wf.data.get((a, b), 0.0) / plat.bw.mean()

    prio = allocator.priority(wf, W, cbar)

    # ready list: max-heap keyed on the allocator's priority
    cnt = np.array([len(p) for p in wf.preds])
    heap = [(-prio[i], i) for i in range(m) if cnt[i] == 0]
    heapq.heapify(heap)

    tl = [Timeline() for _ in range(n)]
    assign = np.full(m, -1, dtype=int)
    S = np.full(m, 0.0)
    F = np.full(m, 0.0)
    rdy_of = np.zeros(m)
    order = []                                  # scheduling order
    started = np.zeros(m, dtype=bool)

    clock = 0.0
    tick = 0
    queue = []                                  # deferred feedback queue Q
    ckpt_every = max(1, m // max(1, checkpoints))
    next_ckpt = ckpt_every

    trace_rows = [] if trace else None
    n_moves = 0
    n_candidates = 0
    n_gapfill = 0

    def comm(p, k):
        if assign[p] < 0 or assign[k] < 0 or assign[p] == assign[k]:
            return 0.0
        return wf.data.get((p, k), 0.0) / plat.bw[assign[k]]

    while heap:
        i = heapq.heappop(heap)[1]
        rho_now = pert.at_task(tick, int(wf.types[i]))

        # ---- ready time from predecessors, per candidate machine (Eq. 6) ---
        # Communication is charged at the *receiving* machine's bandwidth
        # (Eq. 3), so the ready time depends on the candidate machine.
        rdy_vec = np.zeros(n)
        for p in wf.preds[i]:
            vol = wf.data.get((p, i), 0.0)
            c = vol / plat.bw
            c[assign[p]] = 0.0                  # co-located: no transfer
            rdy_vec = np.maximum(rdy_vec, F[p] + c)

        # ---- candidate start / finish estimates ----------------------------
        est_dur = allocator.estimated_duration(i, W, rho_now, protocol)
        Sij = np.empty(n)
        for j in range(n):
            Sij[j] = (tl[j].append_point(rdy_vec[j]) if conservative_estimate
                      else tl[j].earliest_slot(rdy_vec[j], est_dur[j]))
        Fij = Sij + est_dur

        clock = max(clock, float(Sij.min()))    # planning clock (Alg. 1, line 11)

        # ---- P1: release causally available feedback -----------------------
        if queue:
            keep = []
            for (fin, jj, rw, tok) in queue:
                if fin <= clock:
                    allocator.observe(jj, rw, tok)
                else:
                    keep.append((fin, jj, rw, tok))
            queue = keep

        # ---- machine selection ---------------------------------------------
        load = np.array([t.busy() for t in tl])
        j_star = allocator.select(i, W, Sij, Fij, load, plat, wf)

        # ---- commit with the realised duration ------------------------------
        # Commit.  The scheduler reserved a slot long enough for its own
        # estimate; if the task overruns and no longer fits that reservation,
        # the placement misses and falls back to the end of the machine's
        # timeline.  This keeps Eq. (7) satisfied without ever letting rho
        # enter an estimate (P3).
        real_dur = W_true[i, j_star] * rho_now[j_star]
        s_real = tl[j_star].earliest_slot(rdy_vec[j_star], real_dur)
        if s_real < float(Sij[j_star]) - 1e-9:
            n_gapfill += 1
        tl[j_star].insert(s_real, real_dur)
        assign[i] = j_star
        S[i], F[i] = s_real, s_real + real_dur
        rdy_of[i] = float(rdy_vec[j_star])
        order.append(i)

        # ---- reward (Eq. 12) and feedback -----------------------------------
        wmin = W[i].min()
        if protocol.p2:
            denom = real_dur
        else:                                   # P2 off: counterfactual reward
            denom = float((W[i] * rho_now).min())
        rew = float(np.clip(wmin / max(denom, 1e-12), 0.0, 1.0))
        token = allocator.last_token()
        if protocol.p1:
            queue.append((F[i], j_star, rew, token))
        else:
            allocator.observe(j_star, rew, token)

        if trace:
            trace_rows.append(dict(k=len(order), rho=pert.at(tick).copy(),
                                   rho_hat=allocator.rho_hat_snapshot()))

        # ---- successors ------------------------------------------------------
        for k in wf.succs[i]:
            cnt[k] -= 1
            if cnt[k] == 0:
                heapq.heappush(heap, (-prio[k], k))

        tick += 1

        # ---- checkpoint reassignment (Section 3.3.6) --------------------------
        if reassign_mode != "none" and tick >= next_ckpt:
            next_ckpt += ckpt_every
            mv, cand = _reassign(wf, plat, W, W_true, tl, assign, S, F, order, clock,
                                 allocator, protocol, reassign_mode,
                                 theta_imb, theta_bal, move_budget, pert, tick)
            n_moves += mv
            n_candidates += cand

    res = _metrics(wf, plat, W_true, tl, assign, S, F, rdy_of)
    res["moves"] = n_moves
    res["gap_fills"] = n_gapfill
    res["candidates"] = n_candidates
    if trace:
        res["trace"] = trace_rows
        res["rho_final"] = pert.final()
    return res


# --------------------------------------------------------------------------- #
#  Checkpoint reassignment (Section 3.3.6, conditions C1-C4)
# --------------------------------------------------------------------------- #
def _project(wf, W, assign, order, pending_set, tl, plat, clock, F):
    """Re-project the makespan of all not-yet-started tasks using profiled W.

    O(m + e); uses W only, so it is safe under P3.
    """
    avail = np.array([max([iv[1] for iv in t.iv if iv[0] <= clock], default=clock)
                      for t in tl], dtype=float)
    Fp = {}
    mk = clock
    for i in order:
        if i not in pending_set:
            continue
        j = assign[i]
        rdy = 0.0
        for p in wf.preds[i]:
            rdy = max(rdy, Fp.get(p, F[p]))     # committed F for finished preds
        st = max(avail[j], rdy)
        fin = st + W[i, j]
        avail[j] = fin
        Fp[i] = fin
        mk = max(mk, fin)
    return mk


def _reassign(wf, plat, W, W_true, tl, assign, S, F, order, clock, allocator, protocol,
              mode, theta_imb, theta_bal, budget, pert, tick):
    """One checkpoint of globally verified reassignment."""
    n = W.shape[1]
    pending = [i for i in order if S[i] > clock]
    # A checkpoint with fewer pending tasks than machines cannot rebalance
    # anything: the load-pressure ratio of Eq. (16) is degenerate when the
    # pending work sits on a handful of machines.  Skip it (decision R10,
    # docs/IMPLEMENTATION_NOTES.md).  At m = 1000 the working set has median
    # size 2 and maximum 7 against n = 34, so this guard fires at every
    # checkpoint and the three reassignment modes coincide exactly
    # (Section 4.1.3 of the paper).
    if len(pending) < W.shape[1]:
        return 0, 0
    pending_set = set(pending)

    # load pressure, Eq. (16): profiled cost, allocator-agnostic
    pressure_num = np.zeros(n)
    for i in pending:
        pressure_num[assign[i]] += W[i, assign[i]]
    denom = pressure_num.mean()
    if denom <= 0:
        return 0, 0
    L = pressure_num / denom
    if mode == "predictive":
        # Project one checkpoint forward by adding the unfinished portion of
        # the work already running on each machine, so that a machine whose
        # current task still has a long tail counts as more heavily loaded.
        running = np.zeros(n)
        for i in order:
            if S[i] <= clock < F[i]:
                running[assign[i]] += F[i] - clock
        L = (pressure_num + running) / max((pressure_num + running).mean(), 1e-12)
    hot = [j for j in range(n) if L[j] > theta_imb]
    if not hot:
        return 0, 0

    base = _project(wf, W, assign, order, pending_set, tl, plat, clock, F)
    moves = 0
    cands = 0
    for j in sorted(hot, key=lambda x: -L[x]):
        mine = [i for i in pending if assign[i] == j]
        mine.sort(key=lambda i: plat.matching(wf.types[[i]])[0, j])
        for i in mine:
            if moves >= budget:
                return moves, cands
            # C1 and C2
            ok = []
            for k in range(n):
                if k == j:
                    continue
                Lk = (pressure_num[k] + W[i, k]) / denom
                Lj = (pressure_num[j] - W[i, j]) / denom
                if Lk < theta_imb and (Lk - Lj) <= theta_bal:
                    ok.append(k)
            if not ok:
                continue
            # destination preference: the allocator's own score
            pref = allocator.pair_score(i, W, np.array(ok), plat, wf, pressure_num, denom)
            k_star = int(ok[int(np.argmax(pref))])
            cands += 1
            old = assign[i]
            assign[i] = k_star
            if protocol.p4:
                newmk = _project(wf, W, assign, order, pending_set, tl, plat, clock, F)
                accept = newmk <= base + 1e-9
            else:
                accept = True                    # local admission only
            if accept:
                pressure_num[old] -= W[i, old]
                pressure_num[k_star] += W[i, k_star]
                if protocol.p4:
                    base = newmk
                moves += 1
            else:
                assign[i] = old

    if moves:
        _replay(wf, plat, W_true, tl, assign, S, F, order, pending, clock, pert, tick)
    return moves, cands


def _replay(wf, plat, W_true, tl, assign, S, F, order, pending, clock, pert, tick):
    """Rebuild the tail of every timeline after accepted reassignments."""
    for t in tl:
        t.drop_after(clock)
    rho = pert.at(tick)
    for i in order:
        if S[i] <= clock:
            continue
        j = assign[i]
        rdy = 0.0
        for p in wf.preds[i]:
            c = 0.0 if assign[p] == j else wf.data.get((p, i), 0.0) / plat.bw[j]
            rdy = max(rdy, F[p] + c)
        dur = W_true[i, j] * rho[j]
        st = tl[j].earliest_slot(max(rdy, clock), dur)
        tl[j].insert(st, dur)
        S[i], F[i] = st, st + dur


# --------------------------------------------------------------------------- #
#  Metrics (Section 3.3.8)
# --------------------------------------------------------------------------- #
def _metrics(wf, plat, W, tl, assign, S, F, rdy_of):
    cmax = float(F.max())
    busy = np.array([t.busy() for t in tl])
    u = busy / cmax if cmax > 0 else np.zeros_like(busy)
    ubar = float(u.mean())
    sigma = float(np.sqrt(((u - ubar) ** 2).mean()))
    delay = float(np.mean(S - rdy_of))
    M = plat.matching(wf.types)
    mbar = float(np.mean([M[i, assign[i]] for i in range(wf.m)]))
    energy = float(np.sum(plat.p_idle * cmax + (plat.p_max - plat.p_idle) * busy))
    return dict(makespan=cmax, util=100.0 * ubar, sigma_load=100.0 * sigma,
                delay=delay, matching=mbar, energy=energy / 1e3,
                util_per_machine=(100.0 * u).tolist(), assign=assign.tolist(),
                finish_sorted=np.sort(F).tolist())
