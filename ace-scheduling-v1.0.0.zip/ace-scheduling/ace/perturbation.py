"""Runtime perturbation rho_j(t) >= 1 (Section 3).

The manuscript specifies: "a clipped random walk representing ageing with
transient interference episodes that ramp over several checkpoints", never
observable to the scheduler except when condition P3 is relaxed, with a single
"perturbation intensity" parameter set to 2.0 (Supplementary Table S4).

RECONSTRUCTION NOTES
--------------------
1. The stochastic parameters of the walk and of the episodes are not given in
   the manuscript.  They are fixed here, declared in config/default.yaml, and
   were chosen once so that the most degraded machines reach a slowdown of
   roughly 2.5-3.0 by the end of a 1000-task workflow at intensity 2.0.
   They are expressed per *run* rather than per tick, so that the severity of
   the environment does not change with m.
2. rho_j is indexed by the global dispatch counter (0..m-1) rather than by
   wall-clock simulated time.  Every allocator dispatches exactly m tasks, so
   this makes the realisation of rho_j(t) *identical* across allocators for a
   given seed, which is what Section 4.0.2 requires ("All methods use the same
   ... realisations of rho_j(t)").  Indexing by simulated time would make the
   realisation depend on the schedule and would destroy the pairing.
"""
from __future__ import annotations
import numpy as np


class Perturbation:
    """Pre-computed trace rho[t, j] over t = 0..m-1 dispatch ticks."""

    def __init__(self, rng: np.random.Generator, n: int, m: int,
                 intensity: float = 2.0, mode: str = "machine",
                 age_drift_run: float = 0.55, age_sigma_run: float = 0.40,
                 episodes_run: float = 1.5,
                 episode_len_frac: tuple = (0.03, 0.10),
                 episode_amp: tuple = (0.15, 0.45)):
        if m < 2 or n < 1:
            raise ValueError("perturbation needs m >= 2 and n >= 1")
        if mode not in ("machine", "tasktype", "twosided"):
            raise ValueError(f"unknown perturbation mode {mode!r}")
        self.n, self.m, self.intensity, self.mode = n, m, intensity, mode
        k = intensity / 2.0                      # 2.0 is the reference intensity

        # --- ageing: non-negative clipped random walk -----------------------
        mu = age_drift_run * k / m               # per-tick drift
        sd = age_sigma_run * k / np.sqrt(m)      # per-tick volatility
        step = rng.normal(mu, sd, (m, n))
        ages = np.empty((m, n))
        g = np.zeros(n)
        for t in range(m):
            g = np.maximum(0.0, g + step[t])     # clipped at zero
            ages[t] = g

        # --- transient interference episodes, ramping up then down ----------
        inter = np.zeros((m, n))
        p = episodes_run * k / m                 # per-tick episode start prob.
        for j in range(n):
            t = 0
            while t < m:
                if rng.random() < p:
                    L = min(max(4, int(rng.uniform(*episode_len_frac) * m)), m - t)
                    if L < 4:            # too close to the end for a full ramp
                        break
                    up = np.linspace(0.0, 1.0, L // 2, endpoint=False)
                    down = np.linspace(1.0, 0.0, L - L // 2)
                    A = rng.uniform(*episode_amp) * k
                    inter[t:t + L, j] += A * np.concatenate([up, down])
                    t += L
                else:
                    t += 1

        base = ages + inter                      # (m, n), non-negative

        if mode == "machine":
            # In-class: the perturbation is exactly a machine-level
            # multiplicative factor, which is assumption (A2).
            self.rho = np.maximum(1.0, 1.0 + base)
            self.rho_task = None
        elif mode == "tasktype":
            # OUT OF CLASS: the slowdown differs by task type on the same
            # machine, so no single scalar per machine can represent it.
            # Each (machine, type) pair gets an independent multiplier of the
            # shared machine-level component.
            w = rng.uniform(0.35, 1.65, (n, 3))
            self.rho_task = np.maximum(1.0, 1.0 + base[:, :, None] * w[None, :, :])
            self.rho = self.rho_task.mean(axis=2)
        else:                                    # twosided
            # OUT OF CLASS: log rho is a zero-mean Ornstein-Uhlenbeck process,
            # so machines may run FASTER than profiled and the clip of
            # Eq. (12) becomes binding.
            # Stationary sd of log rho is 0.30 * k, giving rho roughly in
            # [0.55, 1.8]; mean-reversion length is m/3 dispatch ticks.
            theta = 3.0 / m
            target_sd = 0.30 * k
            sigma = target_sd * np.sqrt(2.0 * theta)
            x = rng.normal(0.0, target_sd, n)      # start in the stationary law
            log_rho = np.empty((m, n))
            eps = rng.normal(0.0, 1.0, (m, n))
            for t in range(m):
                x = x - theta * x + sigma * eps[t]
                log_rho[t] = x
            self.rho = np.exp(log_rho)
            self.rho_task = None

    def at(self, tick: int) -> np.ndarray:
        """Machine-marginal slowdown vector at a dispatch tick."""
        return self.rho[min(max(tick, 0), self.m - 1)]

    def at_task(self, tick: int, tau: int) -> np.ndarray:
        """Slowdown actually experienced by a task of type tau on each machine.

        Identical to at() unless the perturbation is task-type dependent, in
        which case it lies outside the hypothesis class of a one-scalar-per-
        machine correction.
        """
        t = min(max(tick, 0), self.m - 1)
        if self.rho_task is None:
            return self.rho[t]
        return self.rho_task[t, :, int(tau)]

    def final(self) -> np.ndarray:
        """Ground-truth ranking target used in Section 4.1.1."""
        return self.rho[-1]
