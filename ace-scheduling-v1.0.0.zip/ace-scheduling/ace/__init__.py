"""Reference implementation of adaptive cost-estimate (ACE) scheduling.

Implements the model and methods of Section 3 of the manuscript
"Adaptive cost-estimate scheduling: online correction of profiled
task-machine costs in dynamic heterogeneous clouds".

Every module is deterministic given the seed passed to its constructor.
"""
__version__ = "1.0.0"
