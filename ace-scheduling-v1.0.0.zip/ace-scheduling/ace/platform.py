"""Cluster model: machine classes, capabilities, profiled cost matrix, power.

Implements Eq. (2) (profiled cost) and Eq. (3) (communication) of the paper,
with the affinity penalties of Table 3.

RECONSTRUCTION NOTE
-------------------
The manuscript fixes n = 34 (12 HPC, 11 HT, 11 BC), P_idle = 0.62 P_max and
P_max ~ U(180, 270), but does not state the distributions of the capability
values s_j, q_j, mu_j, bw_j.  The class-conditional ranges below are a
reconstruction chosen so that (a) each class dominates the dimension it is
named for, and (b) the resulting W has the heterogeneity the paper assumes.
They are declared in config/default.yaml and are easy to change.
"""
from __future__ import annotations
import numpy as np

CLASSES = ("HPC", "HT", "BC")
TYPES = ("CI", "IO", "HY")

# Table 3: affinity penalty aff(tau_i, type(V_j)); rows CI/IO/HY, cols HPC/HT/BC
AFFINITY = np.array([[1.00, 1.38, 1.15],
                     [1.38, 1.00, 1.15],
                     [1.15, 1.15, 1.00]])
# Matching degree M: 1 preferred, 0.5 fallback, 0 mismatch (caption of Table 3)
MATCHING = np.array([[1.0, 0.0, 0.5],
                     [0.0, 1.0, 0.5],
                     [0.5, 0.5, 1.0]])

# Reconstruction: class-conditional capability ranges (see module docstring).
CAP_RANGES = {
    "HPC": dict(s=(1.30, 1.70), q=(0.70, 1.00), mu=(0.80, 1.20)),
    "HT":  dict(s=(0.70, 1.00), q=(1.30, 1.70), mu=(0.80, 1.20)),
    "BC":  dict(s=(1.00, 1.30), q=(1.00, 1.30), mu=(1.00, 1.40)),
}
MEM_COEF = 0.35            # coefficient in Eq. (2), stated in the manuscript


class Platform:
    """A heterogeneous cluster of n machines in three classes."""

    def __init__(self, rng: np.random.Generator, n_hpc=12, n_ht=11, n_bc=11):
        counts = {"HPC": n_hpc, "HT": n_ht, "BC": n_bc}
        self.n = n_hpc + n_ht + n_bc
        self.klass = np.array(sum([[c] * counts[c] for c in CLASSES], []))
        self.kidx = np.array([CLASSES.index(c) for c in self.klass])

        s, q, mu = np.empty(self.n), np.empty(self.n), np.empty(self.n)
        for j, c in enumerate(self.klass):
            r = CAP_RANGES[c]
            s[j] = rng.uniform(*r["s"])
            q[j] = rng.uniform(*r["q"])
            mu[j] = rng.uniform(*r["mu"])
        self.s, self.q, self.mu = s, q, mu
        self.bw = rng.uniform(0.80, 1.60, self.n)

        # Power model (Section 4): P_max ~ U(180,270), P_idle = 0.62 P_max.
        self.p_max = rng.uniform(180.0, 270.0, self.n)
        self.p_idle = 0.62 * self.p_max

        # Normalised capabilities: hat-quantities, used ONLY in Eq. (10).
        self.s_hat = _minmax(self.s)
        self.q_hat = _minmax(self.q)
        self.mu_hat = _minmax(self.mu)

    def cost_matrix(self, demands: np.ndarray, work: np.ndarray,
                    types: np.ndarray) -> np.ndarray:
        """Profiled execution cost W_ij, Eq. (2).

        demands : (m,3) array of [cpu, mem, io] demands in [0,1]
        work    : (m,) base workloads omega_i
        types   : (m,) integer task types indexing TYPES
        """
        cpu, mem, io = demands[:, 0], demands[:, 1], demands[:, 2]
        base = (np.outer(cpu * work, 1.0 / self.s)
                + np.outer(io * work, 1.0 / self.q)
                + MEM_COEF * np.outer(mem * work, 1.0 / self.mu))
        return base * AFFINITY[np.ix_(types, self.kidx)]

    def matching(self, types: np.ndarray) -> np.ndarray:
        """Task-machine matching degree M(tau_i, type(V_j)), Table 3."""
        return MATCHING[np.ix_(types, self.kidx)]


def _minmax(x: np.ndarray) -> np.ndarray:
    lo, hi = x.min(), x.max()
    return np.zeros_like(x) if hi <= lo else (x - lo) / (hi - lo)
