"""Experiment driver: builds a paired instance and runs one allocator on it.

A single integer seed determines the platform, the workflow, the profiled cost
matrix, the data volumes and the whole realisation of rho_j(t).  Every
allocator evaluated on that seed therefore sees an identical instance and an
identical environment, which is what the paired analysis of Section 4.1
requires.
"""
from __future__ import annotations
import numpy as np

from .platform import Platform
from .workload import layered_dag, mimic_dag, assign_data_volumes
from .perturbation import Perturbation
from .scheduler import Protocol, run_schedule, upward_rank, optimistic_cost_table
from .allocators import HEFT, CPOP, PEFT, RAH, ACE, LinUCB

METHODS = ["CPOP", "PEFT", "HEFT", "LinUCB-C", "RAH", "LinUCB-W", "ACE"]


class Instance:
    """One fully specified experimental instance."""

    def __init__(self, seed, m=1000, ccr=0.5, intensity=2.0, family=None,
                 profiling_sigma=0.0, pert_mode="machine",
                 n_hpc=12, n_ht=11, n_bc=11):
        self.seed, self.m, self.ccr = seed, m, ccr
        rng = np.random.default_rng(seed)
        self.plat = Platform(rng, n_hpc, n_ht, n_bc)
        if family is None:
            self.wf = layered_dag(rng, m, self.plat.n)
        else:
            self.wf = mimic_dag(rng, family, m, self.plat.n)
        self.m = self.wf.m
        self.W_true = self.plat.cost_matrix(self.wf.demands, self.wf.work,
                                            self.wf.types)
        # Profiling error (Section 5.6): the scheduler sees a corrupted W.
        if profiling_sigma > 0:
            noise = rng.lognormal(-0.5 * profiling_sigma ** 2, profiling_sigma,
                                  self.W_true.shape)
            self.W = self.W_true * noise
        else:
            self.W = self.W_true.copy()
        assign_data_volumes(self.wf, self.W, self.plat.bw, ccr, rng)
        self.pert = Perturbation(np.random.default_rng(seed + 900_000),
                                 self.plat.n, self.m, intensity, mode=pert_mode)

    def cbar(self):
        b = self.plat.bw.mean()
        return {e: self.wf.data.get(e, 0.0) / b for e in self.wf.edges}


def make_allocator(name, inst, gamma=0.30, w_eft=1.6, alpha=0.35, lam0=8.0,
                   seed=0):
    """Construct an allocator by name, warm-starting LinUCB-W if required."""
    n = inst.plat.n
    if name == "HEFT":
        return HEFT()
    if name == "CPOP":
        return CPOP()
    if name == "PEFT":
        return PEFT()
    if name == "RAH":
        return RAH(w_eft=w_eft)
    if name == "ACE":
        return ACE(gamma=gamma, w_eft=w_eft, n=n)
    if name in ("LinUCB-W", "LinUCB-C"):
        a = LinUCB(alpha=alpha, lam0=lam0, warm=(name == "LinUCB-W"), n=n,
                   w_eft=w_eft, rng=np.random.default_rng(seed + 12345))
        cb = inst.cbar()
        ru = upward_rank(inst.wf, inst.W, cb)
        oc = optimistic_cost_table(inst.wf, inst.W, cb)
        ocu = 1.0 - oc / max(oc.max(), 1e-12)
        a._fanout = np.array([len(s) for s in inst.wf.succs], dtype=float)
        a._fanout /= max(a._fanout.max(), 1.0)
        a.fit_prior(inst.plat, inst.wf, inst.W, ru, ocu)
        return a
    raise ValueError(f"unknown allocator {name!r}")


def run_one(name, inst, protocol=None, reassign="none", gamma=0.30, w_eft=1.6,
            alpha=0.35, lam0=8.0, trace=False, checkpoints=30):
    """Run one allocator on one instance and return the metric dictionary."""
    protocol = protocol or Protocol()
    alloc = make_allocator(name, inst, gamma, w_eft, alpha, lam0, inst.seed)
    res = run_schedule(inst.wf, inst.plat, inst.W, alloc, inst.pert, protocol,
                       W_true=inst.W_true, reassign_mode=reassign,
                       checkpoints=checkpoints, trace=trace)
    res["method"] = name
    res["seed"] = inst.seed
    res["m"] = inst.m
    if trace and hasattr(alloc, "rho_hat"):
        res["rho_hat_final"] = alloc.rho_hat.copy().tolist()
    return res
