"""Allocators: HEFT, CPOP, PEFT, RAH, ACE and the LinUCB comparator.

Implements Equations (9)-(15) and (17) of the manuscript.  Every allocator
exposes the same four-method interface used by ace.scheduler.run_schedule:

    priority(wf, W, cbar)            -> ready-list key (Algorithm 1)
    estimated_duration(i, W, rho, p) -> per-machine duration estimate
    select(i, W, Sij, Fij, load, plat, wf) -> chosen machine j*
    observe(j, reward)               -> learning update, if any
    pair_score(...)                  -> destination preference for reassignment
"""
from __future__ import annotations
import numpy as np

from .scheduler import upward_rank, downward_rank, optimistic_cost_table

# Weights of Eq. (10): fixed a priori, sum to exactly one.
H_W = dict(eft=0.34, load=0.24, match=0.18, speed=0.12, io=0.06, cpu=0.06)


def _norm_util(F):
    """Normalise a finish-time vector to a utility in [0,1], Eq. (11)."""
    lo, hi = float(F.min()), float(F.max())
    if hi - lo <= 1e-12:
        return np.ones_like(F)
    return 1.0 - (F - lo) / (hi - lo)


class Base:
    name = "BASE"

    def __init__(self, **kw):
        self.kw = kw

    def priority(self, wf, W, cbar):
        return upward_rank(wf, W, cbar)

    def estimated_duration(self, i, W, rho, protocol):
        # P3 relaxed: the environment hands over the true slowdown.
        return W[i] * rho if not protocol.p3 else W[i].copy()

    def select(self, i, W, Sij, Fij, load, plat, wf):
        return int(np.argmin(Fij))

    def observe(self, j, reward, token=None):
        pass

    def last_token(self):
        """Opaque state that must accompany a deferred observation (P1)."""
        return None

    def rho_hat_snapshot(self):
        return None

    def pair_score(self, i, W, cand, plat, wf, pressure, denom):
        return -W[i, cand]


class HEFT(Base):
    name = "HEFT"


class CPOP(Base):
    """Critical Path on a Processor (Topcuoglu et al.)."""
    name = "CPOP"

    def priority(self, wf, W, cbar):
        ru = upward_rank(wf, W, cbar)
        rd = downward_rank(wf, W, cbar)
        self._ru, self._rd = ru, rd
        pr = ru + rd
        crit = pr.max()
        self._critical = set(np.flatnonzero(np.abs(pr - crit) < 1e-6 * max(1.0, crit)))
        # walk the critical path from the entry task
        cur = int(np.argmax([pr[i] if len(wf.preds[i]) == 0 else -1 for i in range(wf.m)]))
        path = [cur]
        while wf.succs[cur]:
            nxt = max(wf.succs[cur], key=lambda k: pr[k])
            if abs(pr[nxt] - crit) > 1e-6 * max(1.0, crit):
                break
            path.append(nxt)
            cur = nxt
        self._critical = set(path)
        self._cp_proc = int(np.argmin(W[list(self._critical)].sum(axis=0)))
        return pr

    def select(self, i, W, Sij, Fij, load, plat, wf):
        if i in self._critical:
            return self._cp_proc
        return int(np.argmin(Fij))


class PEFT(Base):
    """Predict Earliest Finish Time with an optimistic cost table."""
    name = "PEFT"

    def priority(self, wf, W, cbar):
        self._oct = optimistic_cost_table(wf, W, cbar)
        return self._oct.mean(axis=1)

    def select(self, i, W, Sij, Fij, load, plat, wf):
        return int(np.argmin(Fij + self._oct[i]))


class RAH(Base):
    """Resource-aware heuristic of Eq. (10) and (11), with rho_hat == 1."""
    name = "RAH"

    def __init__(self, w_eft=1.6, **kw):
        super().__init__(**kw)
        self.w_eft = w_eft

    def _h(self, i, W, load, plat, wf):
        ell = load / load.max() if load.max() > 0 else np.zeros_like(load)
        M = plat.matching(wf.types[[i]])[0]
        wrow = W[i]
        return (H_W["eft"] * (1.0 - wrow / wrow.max())
                + H_W["load"] * (1.0 - ell)
                + H_W["match"] * M
                + H_W["speed"] * plat.s_hat
                + H_W["io"] * wf.demands[i, 2] * plat.q_hat
                + H_W["cpu"] * wf.demands[i, 0] * plat.s_hat)

    def select(self, i, W, Sij, Fij, load, plat, wf):
        u = _norm_util(Fij)
        return int(np.argmax(self.w_eft * u + self._h(i, W, load, plat, wf)))

    def pair_score(self, i, W, cand, plat, wf, pressure, denom):
        load = pressure
        return self._h(i, W, load, plat, wf)[cand]


class ACE(RAH):
    """Adaptive cost-estimate scheduling (Eqs. 9 and 12-14)."""
    name = "ACE"

    def __init__(self, gamma=0.30, w_eft=1.6, n=34, decay=0.02, **kw):
        super().__init__(w_eft=w_eft, **kw)
        self.gamma, self.decay = gamma, decay
        self.rho_hat = np.ones(n)
        self.k = np.zeros(n)

    def estimated_duration(self, i, W, rho, protocol):
        if not protocol.p3:
            # P3 relaxed: the oracle duration replaces the corrected estimate
            # entirely, so the learned correction does not influence decisions
            # in the P3-off arm; ACE then coincides with RAH under oracle
            # durations (Table 6 of the paper).
            return W[i] * rho
        return W[i] * self.rho_hat              # Eq. (9)

    def observe(self, j, reward, token=None):
        r_inv = 1.0 / max(reward, 1e-12)
        g = self.gamma / (1.0 + self.decay * self.k[j])
        self.rho_hat[j] = (1.0 - g) * self.rho_hat[j] + g * r_inv   # Eq. (13)
        self.k[j] += 1

    def rho_hat_snapshot(self):
        return self.rho_hat.copy()


class LinUCB(RAH):
    """Contextual-bandit comparator, Eq. (17); exact warm start (Section 3.3.7)."""
    name = "LinUCB"
    D = 15

    def __init__(self, alpha=0.35, lam0=8.0, warm=True, n=34, w_eft=1.6,
                 rng=None, lam_h=1e-6, n_prior=600, **kw):
        super().__init__(w_eft=w_eft, **kw)
        self.alpha, self.lam0, self.warm = alpha, lam0, warm
        self.n = n
        self.rng = rng if rng is not None else np.random.default_rng(0)
        self.lam_h, self.n_prior = lam_h, n_prior
        self.theta0 = np.zeros(self.D)
        self.A_inv = np.stack([np.eye(self.D) / lam0 for _ in range(n)])
        self.b = np.zeros((n, self.D))
        self.theta = np.zeros((n, self.D))
        self._last = None

    # -- warm start ---------------------------------------------------------
    def fit_prior(self, plat, wf, W, ranku, oct_util):
        """Least-squares fit of h_ij on N0 random task-machine pairs (Section 3.3.7)."""
        idx_i = self.rng.integers(0, W.shape[0], self.n_prior)
        idx_j = self.rng.integers(0, W.shape[1], self.n_prior)
        Z = np.stack([self._context(i, j, W, np.zeros(self.n), plat, wf,
                                    ranku, oct_util)
                      for i, j in zip(idx_i, idx_j)])
        h = np.array([self._h(i, W, np.zeros(self.n), plat, wf)[j]
                      for i, j in zip(idx_i, idx_j)])
        A = Z.T @ Z + self.lam_h * np.eye(self.D)
        self.theta0 = np.linalg.solve(A, Z.T @ h)
        pred = Z @ self.theta0
        ss = float(((h - h.mean()) ** 2).sum())
        self.prior_r2 = 1.0 - float(((h - pred) ** 2).sum()) / ss if ss > 0 else 1.0
        self.prior_maxres = float(np.abs(h - pred).max())
        if self.warm:
            self.b = np.tile(self.lam0 * self.theta0, (self.n, 1))
            self.theta = np.tile(self.theta0, (self.n, 1))
        return self.prior_r2, self.prior_maxres

    def priority(self, wf, W, cbar):
        self._ranku = upward_rank(wf, W, cbar)
        self._oct = optimistic_cost_table(wf, W, cbar)
        self._fanout = np.array([len(s) for s in wf.succs], dtype=float)
        self._fanout /= max(self._fanout.max(), 1.0)
        self._rn = self._ranku / max(self._ranku.max(), 1e-12)
        self._octu = 1.0 - self._oct / max(self._oct.max(), 1e-12)
        return self._ranku

    def _context(self, i, j, W, load, plat, wf, ranku=None, octu=None):
        rn = (ranku[i] / max(ranku.max(), 1e-12)) if ranku is not None else self._rn[i]
        ou = (octu[i, j]) if octu is not None else self._octu[i, j]
        ell = load / load.max() if load.max() > 0 else np.zeros_like(load)
        wrow = W[i]
        M = plat.matching(wf.types[[i]])[0]
        fo = self._fanout[i] if hasattr(self, "_fanout") else 0.0
        return np.array([
            1.0,
            wf.demands[i, 0], wf.demands[i, 1], wf.demands[i, 2],
            1.0 - wrow[j] / wrow.max(),
            rn, fo,
            1.0 - ell[j],
            plat.s_hat[j], plat.q_hat[j],
            M[j],
            # NOTE: this entry duplicates index 4 (1 - W_ij / max_l W_il), so
            # the 15-feature context spans 14 distinct features.  The ridge
            # prior (lambda0) keeps A_j invertible despite the collinearity.
            # It is preserved as-is because the released results in
            # results/raw/ were produced with it; cf. Supplementary Table S2.
            1.0 - wrow[j] / wrow.max(),
            ou,
            wf.demands[i, 2] * plat.q_hat[j],
            wf.demands[i, 0] * plat.s_hat[j],
        ])

    def select(self, i, W, Sij, Fij, load, plat, wf):
        Z = np.stack([self._context(i, j, W, load, plat, wf) for j in range(self.n)])
        mean = np.einsum("ij,ij->i", self.theta, Z)
        bonus = np.sqrt(np.maximum(np.einsum("ij,ijk,ik->i", Z, self.A_inv, Z), 0.0))
        u0 = _norm_util(Fij)                    # rho_hat == 1 by construction
        score = self.w_eft * u0 + mean + self.alpha * bonus
        j = int(np.argmax(score))
        self._last = (j, Z[j])
        return j

    def last_token(self):
        return None if self._last is None else self._last[1]

    def observe(self, j, reward, token=None):
        if token is None:
            return
        jj, z = j, token
        Ai = self.A_inv[jj]
        Az = Ai @ z
        self.A_inv[jj] = Ai - np.outer(Az, Az) / (1.0 + float(z @ Az))
        self.b[jj] += reward * z
        self.theta[jj] = self.A_inv[jj] @ self.b[jj]


ALLOCATORS = {
    "CPOP": CPOP, "PEFT": PEFT, "HEFT": HEFT, "RAH": RAH,
    "ACE": ACE, "LinUCB-C": LinUCB, "LinUCB-W": LinUCB,
}
