"""Workflow generation: layered random DAGs and structural mimics.

Implements the workload model of Section 4.0.1 and the task-type rule of Eq. (1).

RECONSTRUCTION NOTES
--------------------
The manuscript states: layered DAGs, bounded Poisson in-degree of mean 3,
CCR 0.5, m in {100,250,500,750,1000}, and the depth/width statistics of
Supplementary Tables S3 and S7.  It does not state the layer-width rule, the demand distribution or
the workload distribution.  The choices below were fixed once, before any
result was produced, so as to reproduce the depth and maximum-width columns of
Supplementary Tables S3 and S7; they are declared in config/default.yaml.

  * layer width ~ U(0.6*cap, cap) with cap = min(100, max(n, ceil(m/3)))
  * task type drawn uniformly from {CI, IO, HY}, then demands drawn so that
    Eq. (1) recovers that type given eps_tau = 0.12
  * omega_i ~ U(60, 140)
  * data volumes scaled so that the mean communication time over edges equals
    CCR times the mean profiled execution time.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field

EPS_TAU = 0.12      # Supplementary Table S4
CI, IO, HY = 0, 1, 2


@dataclass
class Workflow:
    m: int
    edges: list                      # list of (parent, child)
    data: dict                       # (i,k) -> data volume
    demands: np.ndarray              # (m,3) [cpu, mem, io]
    work: np.ndarray                 # (m,)
    types: np.ndarray                # (m,) in {CI,IO,HY}
    layers: list = field(default_factory=list)
    preds: list = field(default_factory=list)
    succs: list = field(default_factory=list)
    topo: np.ndarray = None

    def finalise(self):
        self.preds = [[] for _ in range(self.m)]
        self.succs = [[] for _ in range(self.m)]
        for a, b in self.edges:
            self.succs[a].append(b)
            self.preds[b].append(a)
        # layered construction already yields a topological order 0..m-1
        self.topo = np.arange(self.m)
        return self

    @property
    def depth(self):
        return len(self.layers)

    @property
    def max_width(self):
        return max(len(l) for l in self.layers)


def classify(demands: np.ndarray, eps: float = EPS_TAU) -> np.ndarray:
    """Task type from the demand vector, Eq. (1), branches in the stated order."""
    cpu, mem, io = demands[:, 0], demands[:, 1], demands[:, 2]
    dmax, dmin = demands.max(axis=1), demands.min(axis=1)
    t = np.full(len(demands), HY)
    spread = (dmax - dmin) > eps
    t[spread & (cpu == dmax)] = CI                      # second branch
    t[spread & (io == dmax) & (cpu != dmax)] = IO       # third branch
    # remaining spread tasks are memory-dominant -> HY (fourth branch)
    return t


def _draw_demands(rng, m):
    """Draw demands so that Eq. (1) yields a roughly uniform type mix."""
    want = rng.integers(0, 3, m)
    d = np.empty((m, 3))
    for i in range(m):
        if want[i] == HY:                       # all three within eps_tau
            b = rng.uniform(0.30, 0.90)
            d[i] = b + rng.uniform(-0.05, 0.05, 3)
        elif want[i] == CI:                     # cpu dominant
            hi = rng.uniform(0.60, 1.00)
            d[i] = [hi, hi - rng.uniform(0.20, 0.50), hi - rng.uniform(0.20, 0.50)]
        else:                                   # io dominant
            hi = rng.uniform(0.60, 1.00)
            d[i] = [hi - rng.uniform(0.20, 0.50), hi - rng.uniform(0.20, 0.50), hi]
    return np.clip(d, 0.05, 1.0)


def layered_dag(rng, m, n_machines=34, in_degree_mean=3.0):
    """Layered random DAG with bounded Poisson in-degree (Section 4.0.1).

    The in-degree is clipped to [1, min(|previous layer|, 8)]; the cap of 8
    is part of the generator specification (Supplementary Table S4).
    """
    cap = min(100, max(n_machines, int(np.ceil(m / 3))))
    layers, placed = [], 0
    while placed < m:
        w = int(rng.integers(max(1, int(0.6 * cap)), cap + 1))
        w = min(w, m - placed)
        layers.append(list(range(placed, placed + w)))
        placed += w
    edges, data = [], {}
    for li in range(1, len(layers)):
        prev = layers[li - 1]
        for t in layers[li]:
            k = int(rng.poisson(in_degree_mean))
            k = max(1, min(k, len(prev), 8))            # bounded
            for p in rng.choice(prev, size=k, replace=False):
                edges.append((int(p), int(t)))
    demands = _draw_demands(rng, m)
    work = rng.uniform(60.0, 140.0, m)
    wf = Workflow(m, edges, data, demands, work, classify(demands), layers)
    return wf.finalise()


# Structural mimics: (depth, width) profiles matched to the published shapes of
# the named applications.  These are analogues, NOT WfCommons/Pegasus instances
# (stated in Section 4.1).
def mimic_dag(rng, family, m=600, n_machines=34):
    """Structural mimic with the depth/width profile of Supplementary Table S7."""
    if family == "Montage":
        layers_spec = [30, 270, 270, 30]
    elif family == "CyberShake":
        layers_spec = [30, 540, 30]
    elif family == "Epigenomics":
        layers_spec = [24] * 25
    elif family == "LIGO":
        layers_spec = [24] * 25
    else:
        raise ValueError(f"unknown family {family!r}")
    layers_spec = _rescale(layers_spec, m)
    layers, placed = [], 0
    for w in layers_spec:
        layers.append(list(range(placed, placed + w)))
        placed += w
    edges = []
    for li in range(1, len(layers)):
        prev, cur = layers[li - 1], layers[li]
        if family in ("Montage", "CyberShake"):
            mean_k = 2.5 if family == "Montage" else 1.0
            for t in cur:
                k = max(1, min(int(rng.poisson(mean_k)), len(prev), 8))
                for p in rng.choice(prev, size=k, replace=False):
                    edges.append((int(p), int(t)))
        else:                                   # deep pipelines with light fan-in
            k_mean = 2.0 if family == "LIGO" else 1.0
            for idx, t in enumerate(cur):
                k = max(1, min(int(1 + rng.poisson(k_mean - 1 + 1e-9)), len(prev), 4))
                cand = [prev[(idx + o) % len(prev)] for o in range(k)]
                for p in cand:
                    edges.append((int(p), int(t)))
    demands = _draw_demands(rng, placed)
    work = rng.uniform(60.0, 140.0, placed)
    wf = Workflow(placed, edges, {}, demands, work, classify(demands), layers)
    return wf.finalise()


def _rescale(spec, m):
    tot = sum(spec)
    out = [max(1, int(round(w * m / tot))) for w in spec]
    while sum(out) > m:
        out[int(np.argmax(out))] -= 1
    while sum(out) < m:
        out[int(np.argmax(out))] += 1
    return out


def assign_data_volumes(wf: Workflow, W: np.ndarray, bw: np.ndarray,
                        ccr: float, rng) -> None:
    """Set data volumes so that mean communication time = ccr * mean W (Eq. 3)."""
    if not wf.edges:
        return
    target = ccr * float(W.mean()) * float(bw.mean())
    for (a, b) in wf.edges:
        wf.data[(a, b)] = target * rng.uniform(0.5, 1.5)
